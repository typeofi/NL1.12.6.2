var android = {
    app: {
        slice: {
            Slice: {
                Builder: class {
                    build = function (){}
                    addAction = function (arg0/*PendingIntent*/, arg1/*Slice*/, arg2/*String*/){}
                    addRemoteInput = function (arg0/*RemoteInput*/, arg1/*String*/, arg2/*List*/){}
                    addLong = function (arg0/*long*/, arg1/*String*/, arg2/*List*/){}
                    addBundle = function (arg0/*Bundle*/, arg1/*String*/, arg2/*List*/){}
                    addText = function (arg0/*CharSequence*/, arg1/*String*/, arg2/*List*/){}
                    setCallerNeeded = function (arg0/*boolean*/){}
                    addHints = function (arg0/*List*/){}
                    addSubSlice = function (arg0/*Slice*/, arg1/*String*/){}
                    addIcon = function (arg0/*Icon*/, arg1/*String*/, arg2/*List*/){}
                    addInt = function (arg0/*int*/, arg1/*String*/, arg2/*List*/){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    equals = function (arg0/*Object*/){}
                    toString = function (){}
                    hashCode = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
