var android = {
    widget: {
        ThemedSpinnerAdapter: class {
            setDropDownViewTheme = function (arg0/*Theme*/){}
            getDropDownViewTheme = function (){}
            getDropDownView = function (arg0/*int*/, arg1/*View*/, arg2/*ViewGroup*/){}
            isEmpty = function (){}
            getCount = function (){}
            getAutofillOptions = function (){}
            hasStableIds = function (){}
            getViewTypeCount = function (){}
            getItemViewType = function (arg0/*int*/){}
            getView = function (arg0/*int*/, arg1/*View*/, arg2/*ViewGroup*/){}
            getItem = function (arg0/*int*/){}
            getItemId = function (arg0/*int*/){}
            unregisterDataSetObserver = function (arg0/*DataSetObserver*/){}
            registerDataSetObserver = function (arg0/*DataSetObserver*/){}
        }
    }
}
