var java = {
    io: {
        PipedInputStream: class {
            read = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            read = function (){}
            connect = function (arg0/*PipedOutputStream*/){}
            close = function (){}
            available = function (){}
            read = function (arg0/*byte[]*/){}
            mark = function (arg0/*int*/){}
            readAllBytes = function (){}
            readNBytes = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            readNBytes = function (arg0/*int*/){}
            transferTo = function (arg0/*OutputStream*/){}
            skip = function (arg0/*long*/){}
            markSupported = function (){}
            reset = function (){}
            static nullInputStream = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
