var java = {
    io: {
        ObjectStreamConstants: class {
        }
    }
}
