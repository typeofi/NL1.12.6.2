var android = {
    app: {
        ActionBar: {
            LayoutParams: class {
                resolveLayoutDirection = function (arg0/*int*/){}
                setMargins = function (arg0/*int*/, arg1/*int*/, arg2/*int*/, arg3/*int*/){}
                setLayoutDirection = function (arg0/*int*/){}
                getLayoutDirection = function (){}
                setMarginStart = function (arg0/*int*/){}
                isMarginRelative = function (){}
                getMarginStart = function (){}
                getMarginEnd = function (){}
                setMarginEnd = function (arg0/*int*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
