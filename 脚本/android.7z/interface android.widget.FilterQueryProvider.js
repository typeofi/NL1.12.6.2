var android = {
    widget: {
        FilterQueryProvider: class {
            runQuery = function (arg0/*CharSequence*/){}
        }
    }
}
