var android = {
    widget: {
        SimpleAdapter: {
            ViewBinder: class {
                setViewValue = function (arg0/*View*/, arg1/*Object*/, arg2/*String*/){}
            }
        }
    }
}
