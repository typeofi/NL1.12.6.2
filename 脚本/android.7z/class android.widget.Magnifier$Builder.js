var android = {
    widget: {
        Magnifier: {
            Builder: class {
                build = function (){}
                setSize = function (arg0/*int*/, arg1/*int*/){}
                setElevation = function (arg0/*float*/){}
                setSourceBounds = function (arg0/*int*/, arg1/*int*/, arg2/*int*/, arg3/*int*/){}
                setClippingEnabled = function (arg0/*boolean*/){}
                setInitialZoom = function (arg0/*float*/){}
                setCornerRadius = function (arg0/*float*/){}
                setOverlay = function (arg0/*Drawable*/){}
                setDefaultSourceToMagnifierOffset = function (arg0/*int*/, arg1/*int*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
