var java = {
    lang: {
        Thread: class {
            run = function (){}
            toString = function (){}
            isInterrupted = function (){}
            static currentThread = function (){}
            static onSpinWait = function (){}
            getName = function (){}
            join = function (){}
            join = function (arg0/*long*/, arg1/*int*/){}
            join = function (arg0/*long*/){}
            getThreadGroup = function (){}
            setContextClassLoader = function (arg0/*ClassLoader*/){}
            getStackTrace = function (){}
            static holdsLock = function (arg0/*Object*/){}
            checkAccess = function (){}
            static dumpStack = function (){}
            setPriority = function (arg0/*int*/){}
            setDaemon = function (arg0/*boolean*/){}
            start = function (){}
            static yield = function (){}
            static sleep = function (arg0/*long*/, arg1/*int*/){}
            static sleep = function (arg0/*long*/){}
            stop = function (){}
            interrupt = function (){}
            static interrupted = function (){}
            isAlive = function (){}
            suspend = function (){}
            resume = function (){}
            getPriority = function (){}
            setName = function (arg0/*String*/){}
            static activeCount = function (){}
            static enumerate = function (arg0/*Thread[]*/){}
            countStackFrames = function (){}
            isDaemon = function (){}
            getContextClassLoader = function (){}
            static getAllStackTraces = function (){}
            getId = function (){}
            getState = function (){}
            static setDefaultUncaughtExceptionHandler = function (arg0/*UncaughtExceptionHandler*/){}
            static getDefaultUncaughtExceptionHandler = function (){}
            getUncaughtExceptionHandler = function (){}
            setUncaughtExceptionHandler = function (arg0/*UncaughtExceptionHandler*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
