var android = {
    app: {
        usage: {
            UsageStats: class {
                add = function (arg0/*UsageStats*/){}
                getPackageName = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                getFirstTimeStamp = function (){}
                getLastTimeStamp = function (){}
                getLastTimeVisible = function (){}
                getLastTimeUsed = function (){}
                getLastTimeForegroundServiceUsed = function (){}
                getTotalTimeForegroundServiceUsed = function (){}
                getTotalTimeInForeground = function (){}
                getTotalTimeVisible = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
