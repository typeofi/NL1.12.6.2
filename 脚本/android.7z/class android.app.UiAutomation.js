var android = {
    app: {
        UiAutomation: class {
            toString = function (){}
            findFocus = function (arg0/*int*/){}
            setRotation = function (arg0/*int*/){}
            injectInputEvent = function (arg0/*InputEvent*/, arg1/*boolean*/){}
            waitForIdle = function (arg0/*long*/, arg1/*long*/){}
            setRunAsMonkey = function (arg0/*boolean*/){}
            setServiceInfo = function (arg0/*AccessibilityServiceInfo*/){}
            getWindows = function (){}
            takeScreenshot = function (){}
            getServiceInfo = function (){}
            setOnAccessibilityEventListener = function (arg0/*OnAccessibilityEventListener*/){}
            adoptShellPermissionIdentity = function (){}
            adoptShellPermissionIdentity = function (arg0/*String[]*/){}
            dropShellPermissionIdentity = function (){}
            performGlobalAction = function (arg0/*int*/){}
            getWindowsOnAllDisplays = function (){}
            revokeRuntimePermissionAsUser = function (arg0/*String*/, arg1/*String*/, arg2/*UserHandle*/){}
            getWindowContentFrameStats = function (arg0/*int*/){}
            clearWindowContentFrameStats = function (arg0/*int*/){}
            executeAndWaitForEvent = function (arg0/*Runnable*/, arg1/*AccessibilityEventFilter*/, arg2/*long*/){}
            grantRuntimePermissionAsUser = function (arg0/*String*/, arg1/*String*/, arg2/*UserHandle*/){}
            getRootInActiveWindow = function (){}
            executeShellCommand = function (arg0/*String*/){}
            grantRuntimePermission = function (arg0/*String*/, arg1/*String*/){}
            clearWindowAnimationFrameStats = function (){}
            revokeRuntimePermission = function (arg0/*String*/, arg1/*String*/){}
            getWindowAnimationFrameStats = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
