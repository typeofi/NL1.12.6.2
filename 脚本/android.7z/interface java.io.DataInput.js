var java = {
    io: {
        DataInput: class {
            readLine = function (){}
            readInt = function (){}
            readUTF = function (){}
            readFloat = function (){}
            readChar = function (){}
            readFully = function (arg0/*byte[]*/){}
            readFully = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            skipBytes = function (arg0/*int*/){}
            readBoolean = function (){}
            readByte = function (){}
            readUnsignedByte = function (){}
            readShort = function (){}
            readUnsignedShort = function (){}
            readLong = function (){}
            readDouble = function (){}
        }
    }
}
