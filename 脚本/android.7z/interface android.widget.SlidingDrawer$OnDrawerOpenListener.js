var android = {
    widget: {
        SlidingDrawer: {
            OnDrawerOpenListener: class {
                onDrawerOpened = function (){}
            }
        }
    }
}
