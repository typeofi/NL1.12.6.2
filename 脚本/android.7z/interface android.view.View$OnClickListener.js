var android = {
    view: {
        View: {
            OnClickListener: class {
                onClick = function (arg0/*View*/){}
            }
        }
    }
}
