var android = {
    widget: {
        AbsoluteLayout: {
            LayoutParams: class {
                debug = function (arg0/*String*/){}
                resolveLayoutDirection = function (arg0/*int*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
