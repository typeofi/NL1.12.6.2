var android = {
    widget: {
        SearchView: {
            OnCloseListener: class {
                onClose = function (){}
            }
        }
    }
}
