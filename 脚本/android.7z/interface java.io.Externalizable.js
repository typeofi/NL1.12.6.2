var java = {
    io: {
        Externalizable: class {
            readExternal = function (arg0/*ObjectInput*/){}
            writeExternal = function (arg0/*ObjectOutput*/){}
        }
    }
}
