var android = {
    app: {
        AlarmManager: class {
            set = function (arg0/*int*/, arg1/*long*/, arg2/*String*/, arg3/*OnAlarmListener*/, arg4/*Handler*/){}
            set = function (arg0/*int*/, arg1/*long*/, arg2/*PendingIntent*/){}
            setTime = function (arg0/*long*/){}
            setTimeZone = function (arg0/*String*/){}
            cancel = function (arg0/*OnAlarmListener*/){}
            cancel = function (arg0/*PendingIntent*/){}
            setExact = function (arg0/*int*/, arg1/*long*/, arg2/*PendingIntent*/){}
            setExact = function (arg0/*int*/, arg1/*long*/, arg2/*String*/, arg3/*OnAlarmListener*/, arg4/*Handler*/){}
            setWindow = function (arg0/*int*/, arg1/*long*/, arg2/*long*/, arg3/*PendingIntent*/){}
            setWindow = function (arg0/*int*/, arg1/*long*/, arg2/*long*/, arg3/*String*/, arg4/*OnAlarmListener*/, arg5/*Handler*/){}
            getNextAlarmClock = function (){}
            setAlarmClock = function (arg0/*AlarmClockInfo*/, arg1/*PendingIntent*/){}
            setRepeating = function (arg0/*int*/, arg1/*long*/, arg2/*long*/, arg3/*PendingIntent*/){}
            setAndAllowWhileIdle = function (arg0/*int*/, arg1/*long*/, arg2/*PendingIntent*/){}
            setExactAndAllowWhileIdle = function (arg0/*int*/, arg1/*long*/, arg2/*PendingIntent*/){}
            setInexactRepeating = function (arg0/*int*/, arg1/*long*/, arg2/*long*/, arg3/*PendingIntent*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
