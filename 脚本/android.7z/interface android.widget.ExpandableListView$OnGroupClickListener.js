var android = {
    widget: {
        ExpandableListView: {
            OnGroupClickListener: class {
                onGroupClick = function (arg0/*ExpandableListView*/, arg1/*View*/, arg2/*int*/, arg3/*long*/){}
            }
        }
    }
}
