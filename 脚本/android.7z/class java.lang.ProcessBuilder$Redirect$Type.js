var java = {
    lang: {
        ProcessBuilder: {
            Redirect: {
                Type: class {
                    static values = function (){}
                    static valueOf = function (arg0/*String*/){}
                    name = function (){}
                    equals = function (arg0/*Object*/){}
                    toString = function (){}
                    hashCode = function (){}
                    compareTo = function (arg0/*Object*/){}
                    compareTo = function (arg0/*Enum*/){}
                    static valueOf = function (arg0/*Class*/, arg1/*String*/){}
                    getDeclaringClass = function (){}
                    ordinal = function (){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
