var android = {
    widget: {
        Toolbar: {
            OnMenuItemClickListener: class {
                onMenuItemClick = function (arg0/*MenuItem*/){}
            }
        }
    }
}
