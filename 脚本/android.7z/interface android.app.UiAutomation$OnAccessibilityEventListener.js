var android = {
    app: {
        UiAutomation: {
            OnAccessibilityEventListener: class {
                onAccessibilityEvent = function (arg0/*AccessibilityEvent*/){}
            }
        }
    }
}
