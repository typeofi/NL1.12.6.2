var java = {
    lang: {
        AutoCloseable: class {
            close = function (){}
        }
    }
}
