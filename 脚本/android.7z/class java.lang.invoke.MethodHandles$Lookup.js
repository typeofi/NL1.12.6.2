var java = {
    lang: {
        invoke: {
            MethodHandles: {
                Lookup: class {
                    toString = function (){}
                    findClass = function (arg0/*String*/){}
                    defineClass = function (arg0/*byte[]*/){}
                    in = function (arg0/*Class*/){}
                    lookupClass = function (){}
                    findVirtual = function (arg0/*Class*/, arg1/*String*/, arg2/*MethodType*/){}
                    findStatic = function (arg0/*Class*/, arg1/*String*/, arg2/*MethodType*/){}
                    unreflect = function (arg0/*Method*/){}
                    findGetter = function (arg0/*Class*/, arg1/*String*/, arg2/*Class*/){}
                    findSetter = function (arg0/*Class*/, arg1/*String*/, arg2/*Class*/){}
                    findVarHandle = function (arg0/*Class*/, arg1/*String*/, arg2/*Class*/){}
                    findStaticGetter = function (arg0/*Class*/, arg1/*String*/, arg2/*Class*/){}
                    findStaticSetter = function (arg0/*Class*/, arg1/*String*/, arg2/*Class*/){}
                    findStaticVarHandle = function (arg0/*Class*/, arg1/*String*/, arg2/*Class*/){}
                    unreflectSpecial = function (arg0/*Method*/, arg1/*Class*/){}
                    unreflectConstructor = function (arg0/*Constructor*/){}
                    unreflectGetter = function (arg0/*Field*/){}
                    unreflectSetter = function (arg0/*Field*/){}
                    unreflectVarHandle = function (arg0/*Field*/){}
                    revealDirect = function (arg0/*MethodHandle*/){}
                    hasPrivateAccess = function (){}
                    bind = function (arg0/*Object*/, arg1/*String*/, arg2/*MethodType*/){}
                    lookupModes = function (){}
                    dropLookupMode = function (arg0/*int*/){}
                    findConstructor = function (arg0/*Class*/, arg1/*MethodType*/){}
                    accessClass = function (arg0/*Class*/){}
                    findSpecial = function (arg0/*Class*/, arg1/*String*/, arg2/*MethodType*/, arg3/*Class*/){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    equals = function (arg0/*Object*/){}
                    hashCode = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
