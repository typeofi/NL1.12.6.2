var java = {
    lang: {
        ClassLoader: class {
            loadClass = function (arg0/*String*/){}
            static getPlatformClassLoader = function (){}
            static getSystemClassLoader = function (){}
            getName = function (){}
            getResourceAsStream = function (arg0/*String*/){}
            getResource = function (arg0/*String*/){}
            static getSystemResourceAsStream = function (arg0/*String*/){}
            static getSystemResource = function (arg0/*String*/){}
            getResources = function (arg0/*String*/){}
            resources = function (arg0/*String*/){}
            isRegisteredAsParallelCapable = function (){}
            static getSystemResources = function (arg0/*String*/){}
            getParent = function (){}
            getUnnamedModule = function (){}
            getDefinedPackage = function (arg0/*String*/){}
            getDefinedPackages = function (){}
            setDefaultAssertionStatus = function (arg0/*boolean*/){}
            setPackageAssertionStatus = function (arg0/*String*/, arg1/*boolean*/){}
            setClassAssertionStatus = function (arg0/*String*/, arg1/*boolean*/){}
            clearAssertionStatus = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
