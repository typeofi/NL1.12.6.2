var java = {
    io: {
        ObjectOutputStream: {
            PutField: class {
                put = function (arg0/*String*/, arg1/*float*/){}
                put = function (arg0/*String*/, arg1/*long*/){}
                put = function (arg0/*String*/, arg1/*int*/){}
                put = function (arg0/*String*/, arg1/*double*/){}
                put = function (arg0/*String*/, arg1/*Object*/){}
                put = function (arg0/*String*/, arg1/*boolean*/){}
                put = function (arg0/*String*/, arg1/*byte*/){}
                put = function (arg0/*String*/, arg1/*char*/){}
                put = function (arg0/*String*/, arg1/*short*/){}
                write = function (arg0/*ObjectOutput*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
