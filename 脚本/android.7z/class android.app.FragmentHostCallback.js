var android = {
    app: {
        FragmentHostCallback: class {
            onAttachFragment = function (arg0/*Fragment*/){}
            onGetLayoutInflater = function (){}
            onUseFragmentManagerInflaterFactory = function (){}
            onGetHost = function (){}
            onDump = function (arg0/*String*/, arg1/*FileDescriptor*/, arg2/*PrintWriter*/, arg3/*String[]*/){}
            onFindViewById = function (arg0/*int*/){}
            onHasView = function (){}
            onInvalidateOptionsMenu = function (){}
            onShouldSaveFragmentState = function (arg0/*Fragment*/){}
            onStartActivityFromFragment = function (arg0/*Fragment*/, arg1/*Intent*/, arg2/*int*/, arg3/*Bundle*/){}
            onGetWindowAnimations = function (){}
            onHasWindowAnimations = function (){}
            onRequestPermissionsFromFragment = function (arg0/*Fragment*/, arg1/*String[]*/, arg2/*int*/){}
            onStartIntentSenderFromFragment = function (arg0/*Fragment*/, arg1/*IntentSender*/, arg2/*int*/, arg3/*Intent*/, arg4/*int*/, arg5/*int*/, arg6/*int*/, arg7/*Bundle*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
