var java = {
    lang: {
        reflect: {
            Executable: class {
                getModifiers = function (){}
                getName = function (){}
                toGenericString = function (){}
                isSynthetic = function (){}
                getTypeParameters = function (){}
                getDeclaringClass = function (){}
                getAnnotation = function (arg0/*Class*/){}
                getAnnotationsByType = function (arg0/*Class*/){}
                getDeclaredAnnotations = function (){}
                getParameterTypes = function (){}
                isVarArgs = function (){}
                getAnnotatedParameterTypes = function (){}
                getParameterCount = function (){}
                getParameterAnnotations = function (){}
                getGenericParameterTypes = function (){}
                getExceptionTypes = function (){}
                getGenericExceptionTypes = function (){}
                getAnnotatedReturnType = function (){}
                getParameters = function (){}
                getAnnotatedReceiverType = function (){}
                getAnnotatedExceptionTypes = function (){}
                isAnnotationPresent = function (arg0/*Class*/){}
                getAnnotations = function (){}
                getDeclaredAnnotation = function (arg0/*Class*/){}
                getDeclaredAnnotationsByType = function (arg0/*Class*/){}
                static setAccessible = function (arg0/*AccessibleObject[]*/, arg1/*boolean*/){}
                setAccessible = function (arg0/*boolean*/){}
                trySetAccessible = function (){}
                isAccessible = function (){}
                canAccess = function (arg0/*Object*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
