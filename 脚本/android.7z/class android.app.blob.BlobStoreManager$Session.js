var android = {
    app: {
        blob: {
            BlobStoreManager: {
                Session: class {
                    close = function (){}
                    getSize = function (){}
                    commit = function (arg0/*Executor*/, arg1/*Consumer*/){}
                    allowSameSignatureAccess = function (){}
                    isPublicAccessAllowed = function (){}
                    isSameSignatureAccessAllowed = function (){}
                    isPackageAccessAllowed = function (arg0/*String*/, arg1/*byte[]*/){}
                    abandon = function (){}
                    openRead = function (){}
                    allowPublicAccess = function (){}
                    openWrite = function (arg0/*long*/, arg1/*long*/){}
                    allowPackageAccess = function (arg0/*String*/, arg1/*byte[]*/){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    equals = function (arg0/*Object*/){}
                    toString = function (){}
                    hashCode = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
