var android = {
    widget: {
        CalendarView: {
            OnDateChangeListener: class {
                onSelectedDayChange = function (arg0/*CalendarView*/, arg1/*int*/, arg2/*int*/, arg3/*int*/){}
            }
        }
    }
}
