var java = {
    lang: {
        ProcessBuilder: {
            Redirect: class {
                type = function (){}
                equals = function (arg0/*Object*/){}
                hashCode = function (){}
                static to = function (arg0/*File*/){}
                static from = function (arg0/*File*/){}
                file = function (){}
                static appendTo = function (arg0/*File*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                toString = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
