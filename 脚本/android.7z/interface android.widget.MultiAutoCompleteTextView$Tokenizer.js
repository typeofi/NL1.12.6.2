var android = {
    widget: {
        MultiAutoCompleteTextView: {
            Tokenizer: class {
                terminateToken = function (arg0/*CharSequence*/){}
                findTokenEnd = function (arg0/*CharSequence*/, arg1/*int*/){}
                findTokenStart = function (arg0/*CharSequence*/, arg1/*int*/){}
            }
        }
    }
}
