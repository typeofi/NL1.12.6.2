var java = {
    lang: {
        reflect: {
            Method: class {
                invoke = function (arg0/*Object*/, arg1/*Object[]*/){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getModifiers = function (){}
                getName = function (){}
                toGenericString = function (){}
                isSynthetic = function (){}
                getTypeParameters = function (){}
                getDeclaringClass = function (){}
                getAnnotation = function (arg0/*Class*/){}
                getDeclaredAnnotations = function (){}
                getReturnType = function (){}
                getParameterTypes = function (){}
                setAccessible = function (arg0/*boolean*/){}
                isVarArgs = function (){}
                getParameterCount = function (){}
                getParameterAnnotations = function (){}
                getGenericReturnType = function (){}
                getGenericParameterTypes = function (){}
                getExceptionTypes = function (){}
                getGenericExceptionTypes = function (){}
                isBridge = function (){}
                isDefault = function (){}
                getDefaultValue = function (){}
                getAnnotatedReturnType = function (){}
                getAnnotationsByType = function (arg0/*Class*/){}
                getAnnotatedParameterTypes = function (){}
                getParameters = function (){}
                getAnnotatedReceiverType = function (){}
                getAnnotatedExceptionTypes = function (){}
                isAnnotationPresent = function (arg0/*Class*/){}
                getAnnotations = function (){}
                getDeclaredAnnotation = function (arg0/*Class*/){}
                getDeclaredAnnotationsByType = function (arg0/*Class*/){}
                static setAccessible = function (arg0/*AccessibleObject[]*/, arg1/*boolean*/){}
                trySetAccessible = function (){}
                isAccessible = function (){}
                canAccess = function (arg0/*Object*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
