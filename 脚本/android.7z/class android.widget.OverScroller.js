var android = {
    widget: {
        OverScroller: class {
            fling = function (arg0/*int*/, arg1/*int*/, arg2/*int*/, arg3/*int*/, arg4/*int*/, arg5/*int*/, arg6/*int*/, arg7/*int*/, arg8/*int*/, arg9/*int*/){}
            fling = function (arg0/*int*/, arg1/*int*/, arg2/*int*/, arg3/*int*/, arg4/*int*/, arg5/*int*/, arg6/*int*/, arg7/*int*/){}
            setFriction = function (arg0/*float*/){}
            getFinalY = function (){}
            getFinalX = function (){}
            getCurrY = function (){}
            getCurrVelocity = function (){}
            getStartX = function (){}
            forceFinished = function (arg0/*boolean*/){}
            getCurrX = function (){}
            isFinished = function (){}
            startScroll = function (arg0/*int*/, arg1/*int*/, arg2/*int*/, arg3/*int*/, arg4/*int*/){}
            startScroll = function (arg0/*int*/, arg1/*int*/, arg2/*int*/, arg3/*int*/){}
            getStartY = function (){}
            abortAnimation = function (){}
            springBack = function (arg0/*int*/, arg1/*int*/, arg2/*int*/, arg3/*int*/, arg4/*int*/, arg5/*int*/){}
            isOverScrolled = function (){}
            computeScrollOffset = function (){}
            notifyHorizontalEdgeReached = function (arg0/*int*/, arg1/*int*/, arg2/*int*/){}
            notifyVerticalEdgeReached = function (arg0/*int*/, arg1/*int*/, arg2/*int*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
