var java = {
    io: {
        FilenameFilter: class {
            accept = function (arg0/*File*/, arg1/*String*/){}
        }
    }
}
