var android = {
    widget: {
        RatingBar: {
            OnRatingBarChangeListener: class {
                onRatingChanged = function (arg0/*RatingBar*/, arg1/*float*/, arg2/*boolean*/){}
            }
        }
    }
}
