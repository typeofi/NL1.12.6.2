var android = {
    app: {
        ActivityOptions: class {
            toString = function (){}
            update = function (arg0/*ActivityOptions*/){}
            toBundle = function (){}
            setLaunchDisplayId = function (arg0/*int*/){}
            setLockTaskEnabled = function (arg0/*boolean*/){}
            getLaunchBounds = function (){}
            getLockTaskMode = function (){}
            setLaunchBounds = function (arg0/*Rect*/){}
            getLaunchDisplayId = function (){}
            static makeBasic = function (){}
            static makeTaskLaunchBehind = function (){}
            setAppVerificationBundle = function (arg0/*Bundle*/){}
            requestUsageTimeReport = function (arg0/*PendingIntent*/){}
            static makeCustomAnimation = function (arg0/*Context*/, arg1/*int*/, arg2/*int*/){}
            static makeScaleUpAnimation = function (arg0/*View*/, arg1/*int*/, arg2/*int*/, arg3/*int*/, arg4/*int*/){}
            static makeSceneTransitionAnimation = function (arg0/*Activity*/, arg1/*Pair[]*/){}
            static makeSceneTransitionAnimation = function (arg0/*Activity*/, arg1/*View*/, arg2/*String*/){}
            static makeThumbnailScaleUpAnimation = function (arg0/*View*/, arg1/*Bitmap*/, arg2/*int*/, arg3/*int*/){}
            static makeClipRevealAnimation = function (arg0/*View*/, arg1/*int*/, arg2/*int*/, arg3/*int*/, arg4/*int*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
