var java = {
    io: {
        FilterWriter: class {
            write = function (arg0/*String*/, arg1/*int*/, arg2/*int*/){}
            write = function (arg0/*char[]*/, arg1/*int*/, arg2/*int*/){}
            write = function (arg0/*int*/){}
            flush = function (){}
            close = function (){}
            append = function (arg0/*CharSequence*/, arg1/*int*/, arg2/*int*/){}
            append = function (arg0/*CharSequence*/, arg1/*int*/, arg2/*int*/){}
            append = function (arg0/*char*/){}
            append = function (arg0/*char*/){}
            append = function (arg0/*CharSequence*/){}
            append = function (arg0/*CharSequence*/){}
            write = function (arg0/*char[]*/){}
            write = function (arg0/*String*/){}
            static nullWriter = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
