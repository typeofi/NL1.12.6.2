var java = {
    lang: {
        Comparable: class {
            compareTo = function (arg0/*Object*/){}
        }
    }
}
