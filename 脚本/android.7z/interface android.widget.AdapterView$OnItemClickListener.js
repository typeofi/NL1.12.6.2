var android = {
    widget: {
        AdapterView: {
            OnItemClickListener: class {
                onItemClick = function (arg0/*AdapterView*/, arg1/*View*/, arg2/*int*/, arg3/*long*/){}
            }
        }
    }
}
