var android = {
    widget: {
        BaseAdapter: class {
            isEmpty = function (){}
            isEnabled = function (arg0/*int*/){}
            getAutofillOptions = function (){}
            hasStableIds = function (){}
            getViewTypeCount = function (){}
            getItemViewType = function (arg0/*int*/){}
            getDropDownView = function (arg0/*int*/, arg1/*View*/, arg2/*ViewGroup*/){}
            unregisterDataSetObserver = function (arg0/*DataSetObserver*/){}
            registerDataSetObserver = function (arg0/*DataSetObserver*/){}
            areAllItemsEnabled = function (){}
            notifyDataSetChanged = function (){}
            notifyDataSetInvalidated = function (){}
            setAutofillOptions = function (arg0/*CharSequence[]*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
            getCount = function (){}
            getView = function (arg0/*int*/, arg1/*View*/, arg2/*ViewGroup*/){}
            getItem = function (arg0/*int*/){}
            getItemId = function (arg0/*int*/){}
        }
    }
}
