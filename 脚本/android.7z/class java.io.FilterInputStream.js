var java = {
    io: {
        FilterInputStream: class {
            read = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            read = function (arg0/*byte[]*/){}
            read = function (){}
            close = function (){}
            mark = function (arg0/*int*/){}
            skip = function (arg0/*long*/){}
            available = function (){}
            markSupported = function (){}
            reset = function (){}
            readAllBytes = function (){}
            readNBytes = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            readNBytes = function (arg0/*int*/){}
            transferTo = function (arg0/*OutputStream*/){}
            static nullInputStream = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
