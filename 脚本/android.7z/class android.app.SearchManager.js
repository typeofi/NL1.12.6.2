var android = {
    app: {
        SearchManager: class {
            startSearch = function (arg0/*String*/, arg1/*boolean*/, arg2/*ComponentName*/, arg3/*Bundle*/, arg4/*boolean*/){}
            triggerSearch = function (arg0/*String*/, arg1/*ComponentName*/, arg2/*Bundle*/){}
            setOnCancelListener = function (arg0/*OnCancelListener*/){}
            onDismiss = function (arg0/*DialogInterface*/){}
            onCancel = function (arg0/*DialogInterface*/){}
            setOnDismissListener = function (arg0/*OnDismissListener*/){}
            getGlobalSearchActivity = function (){}
            getSearchablesInGlobalSearch = function (){}
            getSearchableInfo = function (arg0/*ComponentName*/){}
            stopSearch = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
