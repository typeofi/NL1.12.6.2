var android = {
    app: {
        Person: class {
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getName = function (){}
            getKey = function (){}
            getIcon = function (){}
            writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
            describeContents = function (){}
            getUri = function (){}
            isBot = function (){}
            toBuilder = function (){}
            isImportant = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            toString = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
