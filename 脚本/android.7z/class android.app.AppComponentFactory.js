var android = {
    app: {
        AppComponentFactory: class {
            instantiateService = function (arg0/*ClassLoader*/, arg1/*String*/, arg2/*Intent*/){}
            instantiateClassLoader = function (arg0/*ClassLoader*/, arg1/*ApplicationInfo*/){}
            instantiateActivity = function (arg0/*ClassLoader*/, arg1/*String*/, arg2/*Intent*/){}
            instantiateReceiver = function (arg0/*ClassLoader*/, arg1/*String*/, arg2/*Intent*/){}
            instantiateApplication = function (arg0/*ClassLoader*/, arg1/*String*/){}
            instantiateProvider = function (arg0/*ClassLoader*/, arg1/*String*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
