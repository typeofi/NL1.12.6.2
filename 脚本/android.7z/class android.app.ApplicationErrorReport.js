var android = {
    app: {
        ApplicationErrorReport: class {
            dump = function (arg0/*Printer*/, arg1/*String*/){}
            writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
            describeContents = function (){}
            readFromParcel = function (arg0/*Parcel*/){}
            static getErrorReportReceiver = function (arg0/*Context*/, arg1/*String*/, arg2/*int*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
