var android = {
    app: {
        LoaderManager: {
            LoaderCallbacks: class {
                onCreateLoader = function (arg0/*int*/, arg1/*Bundle*/){}
                onLoadFinished = function (arg0/*Loader*/, arg1/*Object*/){}
                onLoaderReset = function (arg0/*Loader*/){}
            }
        }
    }
}
