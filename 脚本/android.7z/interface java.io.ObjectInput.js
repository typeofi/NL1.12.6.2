var java = {
    io: {
        ObjectInput: class {
            readObject = function (){}
            read = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            read = function (arg0/*byte[]*/){}
            read = function (){}
            close = function (){}
            skip = function (arg0/*long*/){}
            available = function (){}
            readLine = function (){}
            readInt = function (){}
            readUTF = function (){}
            readFloat = function (){}
            readChar = function (){}
            readFully = function (arg0/*byte[]*/){}
            readFully = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            skipBytes = function (arg0/*int*/){}
            readBoolean = function (){}
            readByte = function (){}
            readUnsignedByte = function (){}
            readShort = function (){}
            readUnsignedShort = function (){}
            readLong = function (){}
            readDouble = function (){}
        }
    }
}
