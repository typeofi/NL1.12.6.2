var java = {
    lang: {
        reflect: {
            Field: class {
                get = function (arg0/*Object*/){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getModifiers = function (){}
                getBoolean = function (arg0/*Object*/){}
                getByte = function (arg0/*Object*/){}
                getShort = function (arg0/*Object*/){}
                getChar = function (arg0/*Object*/){}
                getInt = function (arg0/*Object*/){}
                getLong = function (arg0/*Object*/){}
                getFloat = function (arg0/*Object*/){}
                getDouble = function (arg0/*Object*/){}
                getName = function (){}
                toGenericString = function (){}
                isSynthetic = function (){}
                getDeclaringClass = function (){}
                getAnnotation = function (arg0/*Class*/){}
                getAnnotationsByType = function (arg0/*Class*/){}
                getDeclaredAnnotations = function (){}
                set = function (arg0/*Object*/, arg1/*Object*/){}
                setAccessible = function (arg0/*boolean*/){}
                isEnumConstant = function (){}
                getType = function (){}
                getGenericType = function (){}
                setBoolean = function (arg0/*Object*/, arg1/*boolean*/){}
                setByte = function (arg0/*Object*/, arg1/*byte*/){}
                setChar = function (arg0/*Object*/, arg1/*char*/){}
                setShort = function (arg0/*Object*/, arg1/*short*/){}
                setInt = function (arg0/*Object*/, arg1/*int*/){}
                setLong = function (arg0/*Object*/, arg1/*long*/){}
                setFloat = function (arg0/*Object*/, arg1/*float*/){}
                setDouble = function (arg0/*Object*/, arg1/*double*/){}
                getAnnotatedType = function (){}
                isAnnotationPresent = function (arg0/*Class*/){}
                getAnnotations = function (){}
                getDeclaredAnnotation = function (arg0/*Class*/){}
                getDeclaredAnnotationsByType = function (arg0/*Class*/){}
                static setAccessible = function (arg0/*AccessibleObject[]*/, arg1/*boolean*/){}
                trySetAccessible = function (){}
                isAccessible = function (){}
                canAccess = function (arg0/*Object*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
