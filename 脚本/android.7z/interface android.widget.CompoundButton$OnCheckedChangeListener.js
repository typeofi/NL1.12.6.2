var android = {
    widget: {
        CompoundButton: {
            OnCheckedChangeListener: class {
                onCheckedChanged = function (arg0/*CompoundButton*/, arg1/*boolean*/){}
            }
        }
    }
}
