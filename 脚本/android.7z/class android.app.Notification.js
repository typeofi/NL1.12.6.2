var android = {
    app: {
        Notification: class {
            toString = function (){}
            clone = function (){}
            clone = function (){}
            writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
            describeContents = function (){}
            getAllowSystemGeneratedContextualActions = function (){}
            getSmallIcon = function (){}
            getLocusId = function (){}
            getSettingsText = function (){}
            getBubbleMetadata = function (){}
            getLargeIcon = function (){}
            getGroup = function (){}
            getSortKey = function (){}
            getChannelId = function (){}
            getTimeoutAfter = function (){}
            getBadgeIconType = function (){}
            getShortcutId = function (){}
            findRemoteInputActionPair = function (arg0/*boolean*/){}
            getGroupAlertBehavior = function (){}
            getContextualActions = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
