var java = {
    lang: {
        reflect: {
            WildcardType: class {
                getLowerBounds = function (){}
                getUpperBounds = function (){}
                getTypeName = function (){}
            }
        }
    }
}
