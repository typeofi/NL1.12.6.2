var android = {
    app: {
        AppOpsManager: class {
            static permissionToOp = function (arg0/*String*/){}
            stopWatchingActive = function (arg0/*OnOpActiveChangedListener*/){}
            stopWatchingMode = function (arg0/*OnOpChangedListener*/){}
            noteOpNoThrow = function (arg0/*String*/, arg1/*int*/, arg2/*String*/, arg3/*String*/, arg4/*String*/){}
            noteOpNoThrow = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            finishOp = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            finishOp = function (arg0/*String*/, arg1/*int*/, arg2/*String*/, arg3/*String*/){}
            noteProxyOpNoThrow = function (arg0/*String*/, arg1/*String*/){}
            noteProxyOpNoThrow = function (arg0/*String*/, arg1/*String*/, arg2/*int*/, arg3/*String*/, arg4/*String*/){}
            noteProxyOpNoThrow = function (arg0/*String*/, arg1/*String*/, arg2/*int*/){}
            isOpActive = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            startOp = function (arg0/*String*/, arg1/*int*/, arg2/*String*/, arg3/*String*/, arg4/*String*/){}
            startOp = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            startWatchingMode = function (arg0/*String*/, arg1/*String*/, arg2/*int*/, arg3/*OnOpChangedListener*/){}
            startWatchingMode = function (arg0/*String*/, arg1/*String*/, arg2/*OnOpChangedListener*/){}
            checkOpNoThrow = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            checkPackage = function (arg0/*int*/, arg1/*String*/){}
            noteOp = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            noteOp = function (arg0/*String*/, arg1/*int*/, arg2/*String*/, arg3/*String*/, arg4/*String*/){}
            unsafeCheckOp = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            checkOp = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            unsafeCheckOpRaw = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            noteProxyOp = function (arg0/*String*/, arg1/*String*/, arg2/*int*/, arg3/*String*/, arg4/*String*/){}
            noteProxyOp = function (arg0/*String*/, arg1/*String*/){}
            startOpNoThrow = function (arg0/*String*/, arg1/*int*/, arg2/*String*/, arg3/*String*/, arg4/*String*/){}
            startOpNoThrow = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            unsafeCheckOpRawNoThrow = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            setOnOpNotedCallback = function (arg0/*Executor*/, arg1/*OnOpNotedCallback*/){}
            startWatchingActive = function (arg0/*String[]*/, arg1/*Executor*/, arg2/*OnOpActiveChangedListener*/){}
            unsafeCheckOpNoThrow = function (arg0/*String*/, arg1/*int*/, arg2/*String*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
