var android = {
    app: {
        TaskStackBuilder: class {
            static create = function (arg0/*Context*/){}
            startActivities = function (arg0/*Bundle*/){}
            startActivities = function (){}
            addParentStack = function (arg0/*ComponentName*/){}
            addParentStack = function (arg0/*Class*/){}
            addParentStack = function (arg0/*Activity*/){}
            addNextIntent = function (arg0/*Intent*/){}
            editIntentAt = function (arg0/*int*/){}
            getIntentCount = function (){}
            getIntents = function (){}
            getPendingIntent = function (arg0/*int*/, arg1/*int*/, arg2/*Bundle*/){}
            getPendingIntent = function (arg0/*int*/, arg1/*int*/){}
            addNextIntentWithParentStack = function (arg0/*Intent*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
