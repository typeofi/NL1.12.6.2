var android = {
    app: {
        Application: {
            OnProvideAssistDataListener: class {
                onProvideAssistData = function (arg0/*Activity*/, arg1/*Bundle*/){}
            }
        }
    }
}
