var android = {
    app: {
        ActionBar: {
            OnNavigationListener: class {
                onNavigationItemSelected = function (arg0/*int*/, arg1/*long*/){}
            }
        }
    }
}
