var java = {
    lang: {
        annotation: {
            Annotation: class {
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                annotationType = function (){}
            }
        }
    }
}
