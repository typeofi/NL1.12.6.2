var android = {
    app: {
        WallpaperManager: {
            OnColorsChangedListener: class {
                onColorsChanged = function (arg0/*WallpaperColors*/, arg1/*int*/){}
            }
        }
    }
}
