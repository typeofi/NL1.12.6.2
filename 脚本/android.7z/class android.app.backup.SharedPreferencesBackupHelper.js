var android = {
    app: {
        backup: {
            SharedPreferencesBackupHelper: class {
                writeNewStateDescription = function (arg0/*ParcelFileDescriptor*/){}
                restoreEntity = function (arg0/*BackupDataInputStream*/){}
                performBackup = function (arg0/*ParcelFileDescriptor*/, arg1/*BackupDataOutput*/, arg2/*ParcelFileDescriptor*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
