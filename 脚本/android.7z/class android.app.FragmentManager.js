var android = {
    app: {
        FragmentManager: class {
            isDestroyed = function (){}
            getFragment = function (arg0/*Bundle*/, arg1/*String*/){}
            dump = function (arg0/*String*/, arg1/*FileDescriptor*/, arg2/*PrintWriter*/, arg3/*String[]*/){}
            static enableDebugLogging = function (arg0/*boolean*/){}
            isStateSaved = function (){}
            findFragmentById = function (arg0/*int*/){}
            popBackStack = function (){}
            popBackStack = function (arg0/*String*/, arg1/*int*/){}
            popBackStack = function (arg0/*int*/, arg1/*int*/){}
            putFragment = function (arg0/*Bundle*/, arg1/*String*/, arg2/*Fragment*/){}
            beginTransaction = function (){}
            findFragmentByTag = function (arg0/*String*/){}
            getFragments = function (){}
            invalidateOptionsMenu = function (){}
            unregisterFragmentLifecycleCallbacks = function (arg0/*FragmentLifecycleCallbacks*/){}
            executePendingTransactions = function (){}
            popBackStackImmediate = function (arg0/*int*/, arg1/*int*/){}
            popBackStackImmediate = function (arg0/*String*/, arg1/*int*/){}
            popBackStackImmediate = function (){}
            getBackStackEntryCount = function (){}
            registerFragmentLifecycleCallbacks = function (arg0/*FragmentLifecycleCallbacks*/, arg1/*boolean*/){}
            getPrimaryNavigationFragment = function (){}
            removeOnBackStackChangedListener = function (arg0/*OnBackStackChangedListener*/){}
            addOnBackStackChangedListener = function (arg0/*OnBackStackChangedListener*/){}
            saveFragmentInstanceState = function (arg0/*Fragment*/){}
            getBackStackEntryAt = function (arg0/*int*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
