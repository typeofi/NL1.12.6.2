var android = {
    app: {
        SharedElementCallback: {
            OnSharedElementsReadyListener: class {
                onSharedElementsReady = function (){}
            }
        }
    }
}
