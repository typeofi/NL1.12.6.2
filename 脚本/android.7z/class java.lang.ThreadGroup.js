var java = {
    lang: {
        ThreadGroup: class {
            toString = function (){}
            getName = function (){}
            list = function (){}
            getParent = function (){}
            checkAccess = function (){}
            setDaemon = function (arg0/*boolean*/){}
            stop = function (){}
            interrupt = function (){}
            suspend = function (){}
            resume = function (){}
            activeCount = function (){}
            enumerate = function (arg0/*ThreadGroup[]*/, arg1/*boolean*/){}
            enumerate = function (arg0/*Thread[]*/, arg1/*boolean*/){}
            enumerate = function (arg0/*ThreadGroup[]*/){}
            enumerate = function (arg0/*Thread[]*/){}
            isDaemon = function (){}
            getMaxPriority = function (){}
            uncaughtException = function (arg0/*Thread*/, arg1/*Throwable*/){}
            isDestroyed = function (){}
            setMaxPriority = function (arg0/*int*/){}
            parentOf = function (arg0/*ThreadGroup*/){}
            activeGroupCount = function (){}
            destroy = function (){}
            allowThreadSuspension = function (arg0/*boolean*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
