var android = {
    app: {
        Notification: {
            BubbleMetadata: {
                Builder: class {
                    build = function (){}
                    setIcon = function (arg0/*Icon*/){}
                    setIntent = function (arg0/*PendingIntent*/){}
                    setSuppressNotification = function (arg0/*boolean*/){}
                    setDesiredHeightResId = function (arg0/*int*/){}
                    setAutoExpandBubble = function (arg0/*boolean*/){}
                    setDeleteIntent = function (arg0/*PendingIntent*/){}
                    setDesiredHeight = function (arg0/*int*/){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    equals = function (arg0/*Object*/){}
                    toString = function (){}
                    hashCode = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
