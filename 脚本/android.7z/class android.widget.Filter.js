var android = {
    widget: {
        Filter: class {
            filter = function (arg0/*CharSequence*/, arg1/*FilterListener*/){}
            filter = function (arg0/*CharSequence*/){}
            convertResultToString = function (arg0/*Object*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
