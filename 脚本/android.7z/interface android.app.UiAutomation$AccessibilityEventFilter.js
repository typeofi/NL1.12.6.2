var android = {
    app: {
        UiAutomation: {
            AccessibilityEventFilter: class {
                accept = function (arg0/*AccessibilityEvent*/){}
            }
        }
    }
}
