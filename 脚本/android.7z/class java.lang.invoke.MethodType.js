var java = {
    lang: {
        invoke: {
            MethodType: class {
                returnType = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                parameterType = function (arg0/*int*/){}
                wrap = function (){}
                insertParameterTypes = function (arg0/*int*/, arg1/*Class[]*/){}
                insertParameterTypes = function (arg0/*int*/, arg1/*List*/){}
                changeReturnType = function (arg0/*Class*/){}
                static methodType = function (arg0/*Class*/, arg1/*Class*/, arg2/*Class[]*/){}
                static methodType = function (arg0/*Class*/, arg1/*Class[]*/){}
                static methodType = function (arg0/*Class*/){}
                static methodType = function (arg0/*Class*/, arg1/*Class*/){}
                static methodType = function (arg0/*Class*/, arg1/*MethodType*/){}
                static methodType = function (arg0/*Class*/, arg1/*List*/){}
                dropParameterTypes = function (arg0/*int*/, arg1/*int*/){}
                appendParameterTypes = function (arg0/*Class[]*/){}
                appendParameterTypes = function (arg0/*List*/){}
                parameterCount = function (){}
                static genericMethodType = function (arg0/*int*/, arg1/*boolean*/){}
                static genericMethodType = function (arg0/*int*/){}
                lastParameterType = function (){}
                parameterList = function (){}
                erase = function (){}
                toMethodDescriptorString = function (){}
                parameterArray = function (){}
                changeParameterType = function (arg0/*int*/, arg1/*Class*/){}
                hasPrimitives = function (){}
                hasWrappers = function (){}
                generic = function (){}
                unwrap = function (){}
                static fromMethodDescriptorString = function (arg0/*String*/, arg1/*ClassLoader*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
