var android = {
    app: {
        Notification: {
            BubbleMetadata: class {
                getIcon = function (){}
                getIntent = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                getShortcutId = function (){}
                getAutoExpandBubble = function (){}
                isNotificationSuppressed = function (){}
                getDesiredHeightResId = function (){}
                getDeleteIntent = function (){}
                getDesiredHeight = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
