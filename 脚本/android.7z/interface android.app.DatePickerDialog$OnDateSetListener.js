var android = {
    app: {
        DatePickerDialog: {
            OnDateSetListener: class {
                onDateSet = function (arg0/*DatePicker*/, arg1/*int*/, arg2/*int*/, arg3/*int*/){}
            }
        }
    }
}
