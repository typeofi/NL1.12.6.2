var android = {
    widget: {
        TextView: {
            OnEditorActionListener: class {
                onEditorAction = function (arg0/*TextView*/, arg1/*int*/, arg2/*KeyEvent*/){}
            }
        }
    }
}
