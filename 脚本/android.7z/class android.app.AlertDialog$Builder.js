var android = {
    app: {
        AlertDialog: {
            Builder: class {
                getContext = function (){}
                create = function (){}
                setIcon = function (arg0/*Drawable*/){}
                setIcon = function (arg0/*int*/){}
                setOnKeyListener = function (arg0/*OnKeyListener*/){}
                setTitle = function (arg0/*CharSequence*/){}
                setTitle = function (arg0/*int*/){}
                show = function (){}
                setOnCancelListener = function (arg0/*OnCancelListener*/){}
                setItems = function (arg0/*CharSequence[]*/, arg1/*OnClickListener*/){}
                setItems = function (arg0/*int*/, arg1/*OnClickListener*/){}
                setCursor = function (arg0/*Cursor*/, arg1/*OnClickListener*/, arg2/*String*/){}
                setAdapter = function (arg0/*ListAdapter*/, arg1/*OnClickListener*/){}
                setView = function (arg0/*View*/){}
                setView = function (arg0/*int*/){}
                setMessage = function (arg0/*int*/){}
                setMessage = function (arg0/*CharSequence*/){}
                setCustomTitle = function (arg0/*View*/){}
                setPositiveButton = function (arg0/*int*/, arg1/*OnClickListener*/){}
                setPositiveButton = function (arg0/*CharSequence*/, arg1/*OnClickListener*/){}
                setIconAttribute = function (arg0/*int*/){}
                setNeutralButton = function (arg0/*int*/, arg1/*OnClickListener*/){}
                setNeutralButton = function (arg0/*CharSequence*/, arg1/*OnClickListener*/){}
                setCancelable = function (arg0/*boolean*/){}
                setNegativeButton = function (arg0/*CharSequence*/, arg1/*OnClickListener*/){}
                setNegativeButton = function (arg0/*int*/, arg1/*OnClickListener*/){}
                setOnDismissListener = function (arg0/*OnDismissListener*/){}
                setInverseBackgroundForced = function (arg0/*boolean*/){}
                setSingleChoiceItems = function (arg0/*CharSequence[]*/, arg1/*int*/, arg2/*OnClickListener*/){}
                setSingleChoiceItems = function (arg0/*ListAdapter*/, arg1/*int*/, arg2/*OnClickListener*/){}
                setSingleChoiceItems = function (arg0/*Cursor*/, arg1/*int*/, arg2/*String*/, arg3/*OnClickListener*/){}
                setSingleChoiceItems = function (arg0/*int*/, arg1/*int*/, arg2/*OnClickListener*/){}
                setOnItemSelectedListener = function (arg0/*OnItemSelectedListener*/){}
                setMultiChoiceItems = function (arg0/*CharSequence[]*/, arg1/*boolean[]*/, arg2/*OnMultiChoiceClickListener*/){}
                setMultiChoiceItems = function (arg0/*int*/, arg1/*boolean[]*/, arg2/*OnMultiChoiceClickListener*/){}
                setMultiChoiceItems = function (arg0/*Cursor*/, arg1/*String*/, arg2/*String*/, arg3/*OnMultiChoiceClickListener*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
