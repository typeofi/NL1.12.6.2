var java = {
    io: {
        PrintStream: class {
            println = function (arg0/*double*/){}
            println = function (arg0/*float*/){}
            println = function (arg0/*long*/){}
            println = function (arg0/*Object*/){}
            println = function (arg0/*char[]*/){}
            println = function (arg0/*String*/){}
            println = function (){}
            println = function (arg0/*boolean*/){}
            println = function (arg0/*char*/){}
            println = function (arg0/*int*/){}
            append = function (arg0/*CharSequence*/){}
            append = function (arg0/*CharSequence*/){}
            append = function (arg0/*char*/){}
            append = function (arg0/*char*/){}
            append = function (arg0/*CharSequence*/, arg1/*int*/, arg2/*int*/){}
            append = function (arg0/*CharSequence*/, arg1/*int*/, arg2/*int*/){}
            format = function (arg0/*Locale*/, arg1/*String*/, arg2/*Object[]*/){}
            format = function (arg0/*String*/, arg1/*Object[]*/){}
            write = function (arg0/*int*/){}
            write = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            print = function (arg0/*boolean*/){}
            print = function (arg0/*int*/){}
            print = function (arg0/*double*/){}
            print = function (arg0/*float*/){}
            print = function (arg0/*Object*/){}
            print = function (arg0/*String*/){}
            print = function (arg0/*char[]*/){}
            print = function (arg0/*char*/){}
            print = function (arg0/*long*/){}
            flush = function (){}
            close = function (){}
            checkError = function (){}
            printf = function (arg0/*String*/, arg1/*Object[]*/){}
            printf = function (arg0/*Locale*/, arg1/*String*/, arg2/*Object[]*/){}
            write = function (arg0/*byte[]*/){}
            static nullOutputStream = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
