var android = {
    app: {
        RemoteAction: class {
            clone = function (){}
            clone = function (){}
            dump = function (arg0/*String*/, arg1/*PrintWriter*/){}
            isEnabled = function (){}
            getContentDescription = function (){}
            getIcon = function (){}
            setEnabled = function (arg0/*boolean*/){}
            getTitle = function (){}
            writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
            describeContents = function (){}
            setShouldShowIcon = function (arg0/*boolean*/){}
            getActionIntent = function (){}
            shouldShowIcon = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
