var android = {
    app: {
        RemoteInput: {
            Builder: class {
                build = function (){}
                getExtras = function (){}
                setAllowFreeFormInput = function (arg0/*boolean*/){}
                setEditChoicesBeforeSending = function (arg0/*int*/){}
                addExtras = function (arg0/*Bundle*/){}
                setLabel = function (arg0/*CharSequence*/){}
                setAllowDataType = function (arg0/*String*/, arg1/*boolean*/){}
                setChoices = function (arg0/*CharSequence[]*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
