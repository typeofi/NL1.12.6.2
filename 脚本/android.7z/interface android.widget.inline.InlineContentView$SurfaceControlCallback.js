var android = {
    widget: {
        inline: {
            InlineContentView: {
                SurfaceControlCallback: class {
                    onDestroyed = function (arg0/*SurfaceControl*/){}
                    onCreated = function (arg0/*SurfaceControl*/){}
                }
            }
        }
    }
}
