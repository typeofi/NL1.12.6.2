var android = {
    app: {
        FragmentManager: {
            FragmentLifecycleCallbacks: class {
                onFragmentDestroyed = function (arg0/*FragmentManager*/, arg1/*Fragment*/){}
                onFragmentPreAttached = function (arg0/*FragmentManager*/, arg1/*Fragment*/, arg2/*Context*/){}
                onFragmentPreCreated = function (arg0/*FragmentManager*/, arg1/*Fragment*/, arg2/*Bundle*/){}
                onFragmentActivityCreated = function (arg0/*FragmentManager*/, arg1/*Fragment*/, arg2/*Bundle*/){}
                onFragmentViewDestroyed = function (arg0/*FragmentManager*/, arg1/*Fragment*/){}
                onFragmentViewCreated = function (arg0/*FragmentManager*/, arg1/*Fragment*/, arg2/*View*/, arg3/*Bundle*/){}
                onFragmentSaveInstanceState = function (arg0/*FragmentManager*/, arg1/*Fragment*/, arg2/*Bundle*/){}
                onFragmentCreated = function (arg0/*FragmentManager*/, arg1/*Fragment*/, arg2/*Bundle*/){}
                onFragmentResumed = function (arg0/*FragmentManager*/, arg1/*Fragment*/){}
                onFragmentStopped = function (arg0/*FragmentManager*/, arg1/*Fragment*/){}
                onFragmentAttached = function (arg0/*FragmentManager*/, arg1/*Fragment*/, arg2/*Context*/){}
                onFragmentStarted = function (arg0/*FragmentManager*/, arg1/*Fragment*/){}
                onFragmentDetached = function (arg0/*FragmentManager*/, arg1/*Fragment*/){}
                onFragmentPaused = function (arg0/*FragmentManager*/, arg1/*Fragment*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
