var java = {
    io: {
        ObjectInputValidation: class {
            validateObject = function (){}
        }
    }
}
