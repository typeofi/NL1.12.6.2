var java = {
    lang: {
        Process: class {
            info = function (){}
            isAlive = function (){}
            destroy = function (){}
            getInputStream = function (){}
            getOutputStream = function (){}
            children = function (){}
            pid = function (){}
            getErrorStream = function (){}
            waitFor = function (arg0/*long*/, arg1/*TimeUnit*/){}
            waitFor = function (){}
            exitValue = function (){}
            destroyForcibly = function (){}
            supportsNormalTermination = function (){}
            onExit = function (){}
            toHandle = function (){}
            descendants = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
