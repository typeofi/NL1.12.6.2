var android = {
    widget: {
        TabHost: {
            OnTabChangeListener: class {
                onTabChanged = function (arg0/*String*/){}
            }
        }
    }
}
