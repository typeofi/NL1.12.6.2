var android = {
    app: {
        ActivityManager: {
            AppTask: class {
                startActivity = function (arg0/*Context*/, arg1/*Intent*/, arg2/*Bundle*/){}
                finishAndRemoveTask = function (){}
                setExcludeFromRecents = function (arg0/*boolean*/){}
                getTaskInfo = function (){}
                moveToFront = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
