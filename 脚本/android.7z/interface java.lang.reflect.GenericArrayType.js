var java = {
    lang: {
        reflect: {
            GenericArrayType: class {
                getGenericComponentType = function (){}
                getTypeName = function (){}
            }
        }
    }
}
