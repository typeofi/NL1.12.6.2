var java = {
    lang: {
        reflect: {
            Member: class {
                getModifiers = function (){}
                getName = function (){}
                isSynthetic = function (){}
                getDeclaringClass = function (){}
            }
        }
    }
}
