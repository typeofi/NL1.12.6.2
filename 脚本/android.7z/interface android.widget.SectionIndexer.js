var android = {
    widget: {
        SectionIndexer: class {
            getSections = function (){}
            getPositionForSection = function (arg0/*int*/){}
            getSectionForPosition = function (arg0/*int*/){}
        }
    }
}
