var android = {
    app: {
        AppOpsManager: {
            OnOpChangedListener: class {
                onOpChanged = function (arg0/*String*/, arg1/*String*/){}
            }
        }
    }
}
