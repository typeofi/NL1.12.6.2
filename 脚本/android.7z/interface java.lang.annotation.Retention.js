var java = {
    lang: {
        annotation: {
            Retention: class {
                value = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                annotationType = function (){}
            }
        }
    }
}
