var android = {
    app: {
        Notification: {
            WearableExtender: class {
                clone = function (){}
                clone = function (){}
                getActions = function (){}
                setBackground = function (arg0/*Bitmap*/){}
                getBackground = function (){}
                setGravity = function (arg0/*int*/){}
                getHintContentIntentLaunchesActivity = function (){}
                setHintContentIntentLaunchesActivity = function (arg0/*boolean*/){}
                getGravity = function (){}
                addAction = function (arg0/*Action*/){}
                setHintAvoidBackgroundClipping = function (arg0/*boolean*/){}
                setContentIconGravity = function (arg0/*int*/){}
                setStartScrollBottom = function (arg0/*boolean*/){}
                setHintAmbientBigPicture = function (arg0/*boolean*/){}
                setCustomContentHeight = function (arg0/*int*/){}
                getHintAvoidBackgroundClipping = function (){}
                getHintScreenTimeout = function (){}
                setContentIntentAvailableOffline = function (arg0/*boolean*/){}
                setHintScreenTimeout = function (arg0/*int*/){}
                getStartScrollBottom = function (){}
                getHintAmbientBigPicture = function (){}
                getContentIntentAvailableOffline = function (){}
                getContentIconGravity = function (){}
                getCustomContentHeight = function (){}
                getCustomSizePreset = function (){}
                setHintShowBackgroundOnly = function (arg0/*boolean*/){}
                getHintShowBackgroundOnly = function (){}
                setCustomSizePreset = function (arg0/*int*/){}
                extend = function (arg0/*Builder*/){}
                addPages = function (arg0/*List*/){}
                setDisplayIntent = function (arg0/*PendingIntent*/){}
                setDismissalId = function (arg0/*String*/){}
                clearActions = function (){}
                setContentIcon = function (arg0/*int*/){}
                getDisplayIntent = function (){}
                setContentAction = function (arg0/*int*/){}
                clearPages = function (){}
                getPages = function (){}
                addPage = function (arg0/*Notification*/){}
                addActions = function (arg0/*List*/){}
                getContentIcon = function (){}
                getContentAction = function (){}
                setHintHideIcon = function (arg0/*boolean*/){}
                getHintHideIcon = function (){}
                setBridgeTag = function (arg0/*String*/){}
                getBridgeTag = function (){}
                getDismissalId = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
