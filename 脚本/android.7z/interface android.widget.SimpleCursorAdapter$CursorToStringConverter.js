var android = {
    widget: {
        SimpleCursorAdapter: {
            CursorToStringConverter: class {
                convertToString = function (arg0/*Cursor*/){}
            }
        }
    }
}
