var android = {
    widget: {
        BaseExpandableListAdapter: class {
            isEmpty = function (){}
            unregisterDataSetObserver = function (arg0/*DataSetObserver*/){}
            registerDataSetObserver = function (arg0/*DataSetObserver*/){}
            getChildType = function (arg0/*int*/, arg1/*int*/){}
            getGroupTypeCount = function (){}
            getChildTypeCount = function (){}
            getGroupType = function (arg0/*int*/){}
            areAllItemsEnabled = function (){}
            onGroupCollapsed = function (arg0/*int*/){}
            getCombinedChildId = function (arg0/*long*/, arg1/*long*/){}
            getCombinedGroupId = function (arg0/*long*/){}
            onGroupExpanded = function (arg0/*int*/){}
            notifyDataSetChanged = function (){}
            notifyDataSetInvalidated = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
            getChild = function (arg0/*int*/, arg1/*int*/){}
            hasStableIds = function (){}
            getGroupId = function (arg0/*int*/){}
            getGroup = function (arg0/*int*/){}
            getChildrenCount = function (arg0/*int*/){}
            getGroupCount = function (){}
            getChildId = function (arg0/*int*/, arg1/*int*/){}
            getGroupView = function (arg0/*int*/, arg1/*boolean*/, arg2/*View*/, arg3/*ViewGroup*/){}
            getChildView = function (arg0/*int*/, arg1/*int*/, arg2/*boolean*/, arg3/*View*/, arg4/*ViewGroup*/){}
            isChildSelectable = function (arg0/*int*/, arg1/*int*/){}
        }
    }
}
