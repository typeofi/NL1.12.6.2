var java = {
    io: {
        PushbackReader: class {
            read = function (){}
            read = function (arg0/*char[]*/, arg1/*int*/, arg2/*int*/){}
            close = function (){}
            mark = function (arg0/*int*/){}
            skip = function (arg0/*long*/){}
            markSupported = function (){}
            reset = function (){}
            unread = function (arg0/*char[]*/){}
            unread = function (arg0/*char[]*/, arg1/*int*/, arg2/*int*/){}
            unread = function (arg0/*int*/){}
            ready = function (){}
            read = function (arg0/*char[]*/){}
            read = function (arg0/*CharBuffer*/){}
            transferTo = function (arg0/*Writer*/){}
            static nullReader = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
