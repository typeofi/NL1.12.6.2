var android = {
    widget: {
        Checkable: class {
            isChecked = function (){}
            setChecked = function (arg0/*boolean*/){}
            toggle = function (){}
        }
    }
}
