var android = {
    graphics: {
        BitmapFactory: class {
            static decodeFileDescriptor = function (arg0/*FileDescriptor*/, arg1/*Rect*/, arg2/*Options*/){}
            static decodeFileDescriptor = function (arg0/*FileDescriptor*/){}
            static decodeResourceStream = function (arg0/*Resources*/, arg1/*TypedValue*/, arg2/*InputStream*/, arg3/*Rect*/, arg4/*Options*/){}
            static decodeFile = function (arg0/*String*/, arg1/*Options*/){}
            static decodeFile = function (arg0/*String*/){}
            static decodeResource = function (arg0/*Resources*/, arg1/*int*/){}
            static decodeResource = function (arg0/*Resources*/, arg1/*int*/, arg2/*Options*/){}
            static decodeByteArray = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/, arg3/*Options*/){}
            static decodeByteArray = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            static decodeStream = function (arg0/*InputStream*/, arg1/*Rect*/, arg2/*Options*/){}
            static decodeStream = function (arg0/*InputStream*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
