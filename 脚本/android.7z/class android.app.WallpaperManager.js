var android = {
    app: {
        WallpaperManager: class {
            clear = function (){}
            clear = function (arg0/*int*/){}
            static getInstance = function (arg0/*Context*/){}
            getDrawable = function (){}
            clearWallpaper = function (){}
            setBitmap = function (arg0/*Bitmap*/){}
            setBitmap = function (arg0/*Bitmap*/, arg1/*Rect*/, arg2/*boolean*/, arg3/*int*/){}
            setBitmap = function (arg0/*Bitmap*/, arg1/*Rect*/, arg2/*boolean*/){}
            peekFastDrawable = function (){}
            setStream = function (arg0/*InputStream*/, arg1/*Rect*/, arg2/*boolean*/, arg3/*int*/){}
            setStream = function (arg0/*InputStream*/){}
            setStream = function (arg0/*InputStream*/, arg1/*Rect*/, arg2/*boolean*/){}
            getWallpaperInfo = function (){}
            setResource = function (arg0/*int*/, arg1/*int*/){}
            setResource = function (arg0/*int*/){}
            getWallpaperColors = function (arg0/*int*/){}
            getFastDrawable = function (){}
            getWallpaperFile = function (arg0/*int*/){}
            getBuiltInDrawable = function (arg0/*int*/, arg1/*int*/, arg2/*boolean*/, arg3/*float*/, arg4/*float*/){}
            getBuiltInDrawable = function (){}
            getBuiltInDrawable = function (arg0/*int*/){}
            getBuiltInDrawable = function (arg0/*int*/, arg1/*int*/, arg2/*boolean*/, arg3/*float*/, arg4/*float*/, arg5/*int*/){}
            peekDrawable = function (){}
            getWallpaperId = function (arg0/*int*/){}
            setDisplayPadding = function (arg0/*Rect*/){}
            setWallpaperOffsets = function (arg0/*IBinder*/, arg1/*float*/, arg2/*float*/){}
            getCropAndSetWallpaperIntent = function (arg0/*Uri*/){}
            isWallpaperSupported = function (){}
            addOnColorsChangedListener = function (arg0/*OnColorsChangedListener*/, arg1/*Handler*/){}
            hasResourceWallpaper = function (arg0/*int*/){}
            getDesiredMinimumHeight = function (){}
            suggestDesiredDimensions = function (arg0/*int*/, arg1/*int*/){}
            isSetWallpaperAllowed = function (){}
            removeOnColorsChangedListener = function (arg0/*OnColorsChangedListener*/){}
            forgetLoadedWallpaper = function (){}
            clearWallpaperOffsets = function (arg0/*IBinder*/){}
            getDesiredMinimumWidth = function (){}
            sendWallpaperCommand = function (arg0/*IBinder*/, arg1/*String*/, arg2/*int*/, arg3/*int*/, arg4/*int*/, arg5/*Bundle*/){}
            setWallpaperOffsetSteps = function (arg0/*float*/, arg1/*float*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
