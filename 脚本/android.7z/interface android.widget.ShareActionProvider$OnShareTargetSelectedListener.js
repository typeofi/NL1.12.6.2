var android = {
    widget: {
        ShareActionProvider: {
            OnShareTargetSelectedListener: class {
                onShareTargetSelected = function (arg0/*ShareActionProvider*/, arg1/*Intent*/){}
            }
        }
    }
}
