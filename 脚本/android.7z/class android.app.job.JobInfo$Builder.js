var android = {
    app: {
        job: {
            JobInfo: {
                Builder: class {
                    build = function (){}
                    setClipData = function (arg0/*ClipData*/, arg1/*int*/){}
                    setExtras = function (arg0/*PersistableBundle*/){}
                    setRequiredNetwork = function (arg0/*NetworkRequest*/){}
                    setTransientExtras = function (arg0/*Bundle*/){}
                    setPersisted = function (arg0/*boolean*/){}
                    setMinimumLatency = function (arg0/*long*/){}
                    setPrefetch = function (arg0/*boolean*/){}
                    setPeriodic = function (arg0/*long*/, arg1/*long*/){}
                    setPeriodic = function (arg0/*long*/){}
                    setBackoffCriteria = function (arg0/*long*/, arg1/*int*/){}
                    setRequiresDeviceIdle = function (arg0/*boolean*/){}
                    setRequiresCharging = function (arg0/*boolean*/){}
                    setRequiredNetworkType = function (arg0/*int*/){}
                    setTriggerContentMaxDelay = function (arg0/*long*/){}
                    setEstimatedNetworkBytes = function (arg0/*long*/, arg1/*long*/){}
                    addTriggerContentUri = function (arg0/*TriggerContentUri*/){}
                    setOverrideDeadline = function (arg0/*long*/){}
                    setTriggerContentUpdateDelay = function (arg0/*long*/){}
                    setRequiresBatteryNotLow = function (arg0/*boolean*/){}
                    setRequiresStorageNotLow = function (arg0/*boolean*/){}
                    setImportantWhileForeground = function (arg0/*boolean*/){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    equals = function (arg0/*Object*/){}
                    toString = function (){}
                    hashCode = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
