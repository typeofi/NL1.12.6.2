var java = {
    io: {
        OutputStream: class {
            write = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            write = function (arg0/*byte[]*/){}
            write = function (arg0/*int*/){}
            flush = function (){}
            close = function (){}
            static nullOutputStream = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
