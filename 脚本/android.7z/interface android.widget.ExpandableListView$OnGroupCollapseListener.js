var android = {
    widget: {
        ExpandableListView: {
            OnGroupCollapseListener: class {
                onGroupCollapse = function (arg0/*int*/){}
            }
        }
    }
}
