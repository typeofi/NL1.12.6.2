var android = {
    widget: {
        NumberPicker: {
            OnScrollListener: class {
                onScrollStateChange = function (arg0/*NumberPicker*/, arg1/*int*/){}
            }
        }
    }
}
