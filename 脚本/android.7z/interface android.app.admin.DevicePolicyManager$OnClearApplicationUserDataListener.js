var android = {
    app: {
        admin: {
            DevicePolicyManager: {
                OnClearApplicationUserDataListener: class {
                    onApplicationUserDataCleared = function (arg0/*String*/, arg1/*boolean*/){}
                }
            }
        }
    }
}
