var android = {
    app: {
        job: {
            JobInfo: class {
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getId = function (){}
                getService = function (){}
                getClipData = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                getExtras = function (){}
                getRequiredNetwork = function (){}
                isPersisted = function (){}
                getNetworkType = function (){}
                isRequireCharging = function (){}
                getTransientExtras = function (){}
                static getMinPeriodMillis = function (){}
                getClipGrantFlags = function (){}
                isPeriodic = function (){}
                getFlexMillis = function (){}
                getBackoffPolicy = function (){}
                getIntervalMillis = function (){}
                static getMinFlexMillis = function (){}
                isPrefetch = function (){}
                isRequireBatteryNotLow = function (){}
                getTriggerContentUris = function (){}
                getMinLatencyMillis = function (){}
                getTriggerContentMaxDelay = function (){}
                getEstimatedNetworkUploadBytes = function (){}
                getMaxExecutionDelayMillis = function (){}
                isRequireDeviceIdle = function (){}
                getTriggerContentUpdateDelay = function (){}
                getEstimatedNetworkDownloadBytes = function (){}
                isRequireStorageNotLow = function (){}
                getInitialBackoffMillis = function (){}
                isImportantWhileForeground = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
