var java = {
    lang: {
        StackTraceElement: class {
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getFileName = function (){}
            getLineNumber = function (){}
            getModuleName = function (){}
            getModuleVersion = function (){}
            getClassLoaderName = function (){}
            getClassName = function (){}
            getMethodName = function (){}
            isNativeMethod = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
