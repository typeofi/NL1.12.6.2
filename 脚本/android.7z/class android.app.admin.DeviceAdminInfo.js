var android = {
    app: {
        admin: {
            DeviceAdminInfo: class {
                toString = function (){}
                getPackageName = function (){}
                dump = function (arg0/*Printer*/, arg1/*String*/){}
                isVisible = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                getComponent = function (){}
                getReceiverName = function (){}
                usesPolicy = function (arg0/*int*/){}
                getTagForPolicy = function (arg0/*int*/){}
                loadDescription = function (arg0/*PackageManager*/){}
                loadIcon = function (arg0/*PackageManager*/){}
                loadLabel = function (arg0/*PackageManager*/){}
                getActivityInfo = function (){}
                supportsTransferOwnership = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
