var android = {
    widget: {
        MediaController: {
            MediaPlayerControl: class {
                start = function (){}
                getDuration = function (){}
                pause = function (){}
                isPlaying = function (){}
                canSeekBackward = function (){}
                getAudioSessionId = function (){}
                seekTo = function (arg0/*int*/){}
                canPause = function (){}
                canSeekForward = function (){}
                getCurrentPosition = function (){}
                getBufferPercentage = function (){}
            }
        }
    }
}
