var java = {
    lang: {
        FunctionalInterface: class {
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            annotationType = function (){}
        }
    }
}
