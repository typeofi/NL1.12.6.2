var android = {
    app: {
        VoiceInteractor: {
            Prompt: class {
                toString = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                getVoicePromptAt = function (arg0/*int*/){}
                getVisualPrompt = function (){}
                countVoicePrompts = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
