var android = {
    widget: {
        Advanceable: class {
            advance = function (){}
            fyiWillBeAdvancedByHostKThx = function (){}
        }
    }
}
