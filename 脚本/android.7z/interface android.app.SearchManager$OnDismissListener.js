var android = {
    app: {
        SearchManager: {
            OnDismissListener: class {
                onDismiss = function (){}
            }
        }
    }
}
