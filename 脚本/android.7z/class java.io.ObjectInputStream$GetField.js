var java = {
    io: {
        ObjectInputStream: {
            GetField: class {
                get = function (arg0/*String*/, arg1/*long*/){}
                get = function (arg0/*String*/, arg1/*int*/){}
                get = function (arg0/*String*/, arg1/*short*/){}
                get = function (arg0/*String*/, arg1/*float*/){}
                get = function (arg0/*String*/, arg1/*double*/){}
                get = function (arg0/*String*/, arg1/*Object*/){}
                get = function (arg0/*String*/, arg1/*boolean*/){}
                get = function (arg0/*String*/, arg1/*byte*/){}
                get = function (arg0/*String*/, arg1/*char*/){}
                defaulted = function (arg0/*String*/){}
                getObjectStreamClass = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
