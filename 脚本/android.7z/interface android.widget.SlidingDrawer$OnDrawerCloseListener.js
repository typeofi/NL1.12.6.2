var android = {
    widget: {
        SlidingDrawer: {
            OnDrawerCloseListener: class {
                onDrawerClosed = function (){}
            }
        }
    }
}
