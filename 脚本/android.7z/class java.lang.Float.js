var java = {
    lang: {
        Float: class {
            equals = function (arg0/*Object*/){}
            static toString = function (arg0/*float*/){}
            toString = function (){}
            hashCode = function (){}
            static hashCode = function (arg0/*float*/){}
            static min = function (arg0/*float*/, arg1/*float*/){}
            static max = function (arg0/*float*/, arg1/*float*/){}
            static floatToRawIntBits = function (arg0/*float*/){}
            static floatToIntBits = function (arg0/*float*/){}
            static intBitsToFloat = function (arg0/*int*/){}
            compareTo = function (arg0/*Float*/){}
            compareTo = function (arg0/*Object*/){}
            byteValue = function (){}
            shortValue = function (){}
            intValue = function (){}
            longValue = function (){}
            floatValue = function (){}
            doubleValue = function (){}
            static valueOf = function (arg0/*float*/){}
            static valueOf = function (arg0/*String*/){}
            static toHexString = function (arg0/*float*/){}
            static compare = function (arg0/*float*/, arg1/*float*/){}
            static isNaN = function (arg0/*float*/){}
            isNaN = function (){}
            static parseFloat = function (arg0/*String*/){}
            static isInfinite = function (arg0/*float*/){}
            isInfinite = function (){}
            static isFinite = function (arg0/*float*/){}
            static sum = function (arg0/*float*/, arg1/*float*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
