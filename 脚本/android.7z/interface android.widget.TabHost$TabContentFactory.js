var android = {
    widget: {
        TabHost: {
            TabContentFactory: class {
                createTabContent = function (arg0/*String*/){}
            }
        }
    }
}
