var java = {
    io: {
        PipedOutputStream: class {
            write = function (arg0/*int*/){}
            write = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            connect = function (arg0/*PipedInputStream*/){}
            flush = function (){}
            close = function (){}
            write = function (arg0/*byte[]*/){}
            static nullOutputStream = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
