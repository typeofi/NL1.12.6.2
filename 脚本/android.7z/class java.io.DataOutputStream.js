var java = {
    io: {
        DataOutputStream: class {
            size = function (){}
            write = function (arg0/*int*/){}
            write = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            flush = function (){}
            writeInt = function (arg0/*int*/){}
            writeBytes = function (arg0/*String*/){}
            writeUTF = function (arg0/*String*/){}
            writeFloat = function (arg0/*float*/){}
            writeChar = function (arg0/*int*/){}
            writeBoolean = function (arg0/*boolean*/){}
            writeByte = function (arg0/*int*/){}
            writeShort = function (arg0/*int*/){}
            writeLong = function (arg0/*long*/){}
            writeDouble = function (arg0/*double*/){}
            writeChars = function (arg0/*String*/){}
            write = function (arg0/*byte[]*/){}
            close = function (){}
            static nullOutputStream = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
