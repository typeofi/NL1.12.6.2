var android = {
    widget: {
        RemoteViewsService: {
            RemoteViewsFactory: class {
                getCount = function (){}
                hasStableIds = function (){}
                getViewTypeCount = function (){}
                onDestroy = function (){}
                getItemId = function (arg0/*int*/){}
                onCreate = function (){}
                getViewAt = function (arg0/*int*/){}
                getLoadingView = function (){}
                onDataSetChanged = function (){}
            }
        }
    }
}
