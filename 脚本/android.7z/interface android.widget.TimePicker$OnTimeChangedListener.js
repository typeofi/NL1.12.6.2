var android = {
    widget: {
        TimePicker: {
            OnTimeChangedListener: class {
                onTimeChanged = function (arg0/*TimePicker*/, arg1/*int*/, arg2/*int*/){}
            }
        }
    }
}
