var android = {
    app: {
        VoiceInteractor: {
            Request: class {
                toString = function (){}
                getName = function (){}
                getContext = function (){}
                cancel = function (){}
                getActivity = function (){}
                onCancel = function (){}
                onDetached = function (){}
                onAttached = function (arg0/*Activity*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
