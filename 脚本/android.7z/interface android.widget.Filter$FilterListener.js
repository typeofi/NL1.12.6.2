var android = {
    widget: {
        Filter: {
            FilterListener: class {
                onFilterComplete = function (arg0/*int*/){}
            }
        }
    }
}
