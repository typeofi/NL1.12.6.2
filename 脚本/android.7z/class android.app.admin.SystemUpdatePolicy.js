var android = {
    app: {
        admin: {
            SystemUpdatePolicy: class {
                toString = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                getPolicyType = function (){}
                setFreezePeriods = function (arg0/*List*/){}
                static createPostponeInstallPolicy = function (){}
                static createWindowedInstallPolicy = function (arg0/*int*/, arg1/*int*/){}
                getInstallWindowEnd = function (){}
                static createAutomaticInstallPolicy = function (){}
                getInstallWindowStart = function (){}
                getFreezePeriods = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
