var android = {
    app: {
        usage: {
            UsageStatsManager: class {
                isAppInactive = function (arg0/*String*/){}
                queryEventsForSelf = function (arg0/*long*/, arg1/*long*/){}
                queryUsageStats = function (arg0/*int*/, arg1/*long*/, arg2/*long*/){}
                queryEventStats = function (arg0/*int*/, arg1/*long*/, arg2/*long*/){}
                queryEvents = function (arg0/*long*/, arg1/*long*/){}
                queryAndAggregateUsageStats = function (arg0/*long*/, arg1/*long*/){}
                getAppStandbyBucket = function (){}
                queryConfigurations = function (arg0/*int*/, arg1/*long*/, arg2/*long*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
