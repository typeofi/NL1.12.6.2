var java = {
    lang: {
        invoke: {
            MethodHandle: class {
                invoke = function (arg0/*Object[]*/){}
                invokeExact = function (arg0/*Object[]*/){}
                type = function (){}
                toString = function (){}
                invokeWithArguments = function (arg0/*Object[]*/){}
                invokeWithArguments = function (arg0/*List*/){}
                asType = function (arg0/*MethodType*/){}
                asSpreader = function (arg0/*Class*/, arg1/*int*/){}
                asSpreader = function (arg0/*int*/, arg1/*Class*/, arg2/*int*/){}
                withVarargs = function (arg0/*boolean*/){}
                asCollector = function (arg0/*Class*/, arg1/*int*/){}
                asCollector = function (arg0/*int*/, arg1/*Class*/, arg2/*int*/){}
                asVarargsCollector = function (arg0/*Class*/){}
                isVarargsCollector = function (){}
                asFixedArity = function (){}
                bindTo = function (arg0/*Object*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
