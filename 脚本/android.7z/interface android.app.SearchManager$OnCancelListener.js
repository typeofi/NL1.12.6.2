var android = {
    app: {
        SearchManager: {
            OnCancelListener: class {
                onCancel = function (){}
            }
        }
    }
}
