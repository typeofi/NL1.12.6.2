var java = {
    lang: {
        System: class {
            static exit = function (arg0/*int*/){}
            static runFinalization = function (){}
            static getProperty = function (arg0/*String*/){}
            static getProperty = function (arg0/*String*/, arg1/*String*/){}
            static identityHashCode = function (arg0/*Object*/){}
            static currentTimeMillis = function (){}
            static nanoTime = function (){}
            static arraycopy = function (arg0/*Object*/, arg1/*int*/, arg2/*Object*/, arg3/*int*/, arg4/*int*/){}
            static getSecurityManager = function (){}
            static loadLibrary = function (arg0/*String*/){}
            static mapLibraryName = function (arg0/*String*/){}
            static lineSeparator = function (){}
            static setIn = function (arg0/*InputStream*/){}
            static setOut = function (arg0/*PrintStream*/){}
            static setErr = function (arg0/*PrintStream*/){}
            static console = function (){}
            static inheritedChannel = function (){}
            static setSecurityManager = function (arg0/*SecurityManager*/){}
            static getProperties = function (){}
            static setProperties = function (arg0/*Properties*/){}
            static setProperty = function (arg0/*String*/, arg1/*String*/){}
            static clearProperty = function (arg0/*String*/){}
            static getenv = function (arg0/*String*/){}
            static getenv = function (){}
            static getLogger = function (arg0/*String*/, arg1/*ResourceBundle*/){}
            static getLogger = function (arg0/*String*/){}
            static gc = function (){}
            static load = function (arg0/*String*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
