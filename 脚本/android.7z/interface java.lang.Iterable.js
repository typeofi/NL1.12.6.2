var java = {
    lang: {
        Iterable: class {
            iterator = function (){}
            spliterator = function (){}
            forEach = function (arg0/*Consumer*/){}
        }
    }
}
