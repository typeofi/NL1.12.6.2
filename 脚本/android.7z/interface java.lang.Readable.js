var java = {
    lang: {
        Readable: class {
            read = function (arg0/*CharBuffer*/){}
        }
    }
}
