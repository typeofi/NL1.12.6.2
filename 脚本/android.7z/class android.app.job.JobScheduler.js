var android = {
    app: {
        job: {
            JobScheduler: class {
                enqueue = function (arg0/*JobInfo*/, arg1/*JobWorkItem*/){}
                schedule = function (arg0/*JobInfo*/){}
                cancel = function (arg0/*int*/){}
                cancelAll = function (){}
                getPendingJob = function (arg0/*int*/){}
                getAllPendingJobs = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
