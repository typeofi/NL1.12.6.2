var android = {
    app: {
        Notification: {
            MessagingStyle: {
                Message: class {
                    getTimestamp = function (){}
                    getText = function (){}
                    getExtras = function (){}
                    setData = function (arg0/*String*/, arg1/*Uri*/){}
                    static getMessagesFromBundleArray = function (arg0/*Parcelable[]*/){}
                    getSenderPerson = function (){}
                    getDataMimeType = function (){}
                    getDataUri = function (){}
                    getSender = function (){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    equals = function (arg0/*Object*/){}
                    toString = function (){}
                    hashCode = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
