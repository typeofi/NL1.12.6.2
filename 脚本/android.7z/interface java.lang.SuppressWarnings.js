var java = {
    lang: {
        SuppressWarnings: class {
            value = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            annotationType = function (){}
        }
    }
}
