var android = {
    app: {
        DownloadManager: {
            Request: class {
                setTitle = function (arg0/*CharSequence*/){}
                setDestinationUri = function (arg0/*Uri*/){}
                addRequestHeader = function (arg0/*String*/, arg1/*String*/){}
                setDescription = function (arg0/*CharSequence*/){}
                setMimeType = function (arg0/*String*/){}
                setVisibleInDownloadsUi = function (arg0/*boolean*/){}
                setDestinationInExternalPublicDir = function (arg0/*String*/, arg1/*String*/){}
                setNotificationVisibility = function (arg0/*int*/){}
                setRequiresDeviceIdle = function (arg0/*boolean*/){}
                setAllowedOverRoaming = function (arg0/*boolean*/){}
                setDestinationInExternalFilesDir = function (arg0/*Context*/, arg1/*String*/, arg2/*String*/){}
                setAllowedOverMetered = function (arg0/*boolean*/){}
                setRequiresCharging = function (arg0/*boolean*/){}
                allowScanningByMediaScanner = function (){}
                setShowRunningNotification = function (arg0/*boolean*/){}
                setAllowedNetworkTypes = function (arg0/*int*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
