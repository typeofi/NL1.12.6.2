var android = {
    app: {
        blob: {
            BlobStoreManager: class {
                getRemainingLeaseQuotaBytes = function (){}
                openSession = function (arg0/*long*/){}
                openBlob = function (arg0/*BlobHandle*/){}
                abandonSession = function (arg0/*long*/){}
                acquireLease = function (arg0/*BlobHandle*/, arg1/*CharSequence*/){}
                acquireLease = function (arg0/*BlobHandle*/, arg1/*int*/){}
                acquireLease = function (arg0/*BlobHandle*/, arg1/*CharSequence*/, arg2/*long*/){}
                acquireLease = function (arg0/*BlobHandle*/, arg1/*int*/, arg2/*long*/){}
                getLeasedBlobs = function (){}
                createSession = function (arg0/*BlobHandle*/){}
                releaseLease = function (arg0/*BlobHandle*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
