var java = {
    io: {
        Serializable: class {
        }
    }
}
