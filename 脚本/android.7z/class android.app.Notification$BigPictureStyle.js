var android = {
    app: {
        Notification: {
            BigPictureStyle: class {
                setBigContentTitle = function (arg0/*CharSequence*/){}
                bigPicture = function (arg0/*Bitmap*/){}
                bigLargeIcon = function (arg0/*Bitmap*/){}
                bigLargeIcon = function (arg0/*Icon*/){}
                setSummaryText = function (arg0/*CharSequence*/){}
                build = function (){}
                setBuilder = function (arg0/*Builder*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
