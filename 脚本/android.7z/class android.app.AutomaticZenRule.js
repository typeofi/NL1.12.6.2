var android = {
    app: {
        AutomaticZenRule: class {
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getName = function (){}
            setName = function (arg0/*String*/){}
            getOwner = function (){}
            getCreationTime = function (){}
            isEnabled = function (){}
            setEnabled = function (arg0/*boolean*/){}
            writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
            describeContents = function (){}
            setZenPolicy = function (arg0/*ZenPolicy*/){}
            getZenPolicy = function (){}
            getConditionId = function (){}
            setConditionId = function (arg0/*Uri*/){}
            getInterruptionFilter = function (){}
            setInterruptionFilter = function (arg0/*int*/){}
            setConfigurationActivity = function (arg0/*ComponentName*/){}
            getConfigurationActivity = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
