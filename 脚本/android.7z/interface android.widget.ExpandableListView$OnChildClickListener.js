var android = {
    widget: {
        ExpandableListView: {
            OnChildClickListener: class {
                onChildClick = function (arg0/*ExpandableListView*/, arg1/*View*/, arg2/*int*/, arg3/*int*/, arg4/*long*/){}
            }
        }
    }
}
