var android = {
    widget: {
        ArrayAdapter: class {
            add = function (arg0/*Object*/){}
            remove = function (arg0/*Object*/){}
            clear = function (){}
            addAll = function (arg0/*Collection*/){}
            addAll = function (arg0/*Object[]*/){}
            getContext = function (){}
            insert = function (arg0/*Object*/, arg1/*int*/){}
            sort = function (arg0/*Comparator*/){}
            getCount = function (){}
            getFilter = function (){}
            getPosition = function (arg0/*Object*/){}
            getAutofillOptions = function (){}
            getDropDownView = function (arg0/*int*/, arg1/*View*/, arg2/*ViewGroup*/){}
            getView = function (arg0/*int*/, arg1/*View*/, arg2/*ViewGroup*/){}
            getItem = function (arg0/*int*/){}
            getItemId = function (arg0/*int*/){}
            setNotifyOnChange = function (arg0/*boolean*/){}
            static createFromResource = function (arg0/*Context*/, arg1/*int*/, arg2/*int*/){}
            setDropDownViewTheme = function (arg0/*Theme*/){}
            setDropDownViewResource = function (arg0/*int*/){}
            notifyDataSetChanged = function (){}
            getDropDownViewTheme = function (){}
            isEmpty = function (){}
            isEnabled = function (arg0/*int*/){}
            hasStableIds = function (){}
            getViewTypeCount = function (){}
            getItemViewType = function (arg0/*int*/){}
            unregisterDataSetObserver = function (arg0/*DataSetObserver*/){}
            registerDataSetObserver = function (arg0/*DataSetObserver*/){}
            areAllItemsEnabled = function (){}
            notifyDataSetInvalidated = function (){}
            setAutofillOptions = function (arg0/*CharSequence[]*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
