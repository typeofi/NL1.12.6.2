var android = {
    app: {
        Instrumentation: {
            ActivityMonitor: class {
                getFilter = function (){}
                getResult = function (){}
                isBlocking = function (){}
                onStartActivity = function (arg0/*Intent*/){}
                getHits = function (){}
                getLastActivity = function (){}
                waitForActivity = function (){}
                waitForActivityWithTimeout = function (arg0/*long*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
