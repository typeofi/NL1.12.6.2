var java = {
    io: {
        ObjectStreamClass: class {
            toString = function (){}
            getName = function (){}
            getFields = function (){}
            getField = function (arg0/*String*/){}
            static lookup = function (arg0/*Class*/){}
            forClass = function (){}
            static lookupAny = function (arg0/*Class*/){}
            getSerialVersionUID = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
