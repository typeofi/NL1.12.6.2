var android = {
    app: {
        blob: {
            BlobHandle: class {
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getTag = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                getLabel = function (){}
                getExpiryTimeMillis = function (){}
                static createWithSha256 = function (arg0/*byte[]*/, arg1/*CharSequence*/, arg2/*long*/, arg3/*String*/){}
                getSha256Digest = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
