var android = {
    app: {
        FragmentManager: {
            OnBackStackChangedListener: class {
                onBackStackChanged = function (){}
            }
        }
    }
}
