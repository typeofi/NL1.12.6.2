var android = {
    widget: {
        EdgeEffect: class {
            setSize = function (arg0/*int*/, arg1/*int*/){}
            finish = function (){}
            setColor = function (arg0/*int*/){}
            draw = function (arg0/*Canvas*/){}
            getColor = function (){}
            isFinished = function (){}
            onAbsorb = function (arg0/*int*/){}
            onPull = function (arg0/*float*/, arg1/*float*/){}
            onPull = function (arg0/*float*/){}
            onRelease = function (){}
            getMaxHeight = function (){}
            getBlendMode = function (){}
            setBlendMode = function (arg0/*BlendMode*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
