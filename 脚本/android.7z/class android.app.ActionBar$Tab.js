var android = {
    app: {
        ActionBar: {
            Tab: class {
                setText = function (arg0/*CharSequence*/){}
                setText = function (arg0/*int*/){}
                getTag = function (){}
                getPosition = function (){}
                select = function (){}
                getText = function (){}
                setContentDescription = function (arg0/*CharSequence*/){}
                setContentDescription = function (arg0/*int*/){}
                getContentDescription = function (){}
                getIcon = function (){}
                setIcon = function (arg0/*Drawable*/){}
                setIcon = function (arg0/*int*/){}
                setCustomView = function (arg0/*int*/){}
                setCustomView = function (arg0/*View*/){}
                getCustomView = function (){}
                setTag = function (arg0/*Object*/){}
                setTabListener = function (arg0/*TabListener*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
