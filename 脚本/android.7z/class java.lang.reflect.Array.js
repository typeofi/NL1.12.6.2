var java = {
    lang: {
        reflect: {
            Array: class {
                static get = function (arg0/*Object*/, arg1/*int*/){}
                static getLength = function (arg0/*Object*/){}
                static getBoolean = function (arg0/*Object*/, arg1/*int*/){}
                static getByte = function (arg0/*Object*/, arg1/*int*/){}
                static getShort = function (arg0/*Object*/, arg1/*int*/){}
                static getChar = function (arg0/*Object*/, arg1/*int*/){}
                static getInt = function (arg0/*Object*/, arg1/*int*/){}
                static getLong = function (arg0/*Object*/, arg1/*int*/){}
                static getFloat = function (arg0/*Object*/, arg1/*int*/){}
                static getDouble = function (arg0/*Object*/, arg1/*int*/){}
                static newInstance = function (arg0/*Class*/, arg1/*int*/){}
                static newInstance = function (arg0/*Class*/, arg1/*int[]*/){}
                static set = function (arg0/*Object*/, arg1/*int*/, arg2/*Object*/){}
                static setBoolean = function (arg0/*Object*/, arg1/*int*/, arg2/*boolean*/){}
                static setByte = function (arg0/*Object*/, arg1/*int*/, arg2/*byte*/){}
                static setChar = function (arg0/*Object*/, arg1/*int*/, arg2/*char*/){}
                static setShort = function (arg0/*Object*/, arg1/*int*/, arg2/*short*/){}
                static setInt = function (arg0/*Object*/, arg1/*int*/, arg2/*int*/){}
                static setLong = function (arg0/*Object*/, arg1/*int*/, arg2/*long*/){}
                static setFloat = function (arg0/*Object*/, arg1/*int*/, arg2/*float*/){}
                static setDouble = function (arg0/*Object*/, arg1/*int*/, arg2/*double*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
