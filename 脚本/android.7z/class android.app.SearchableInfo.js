var android = {
    app: {
        SearchableInfo: class {
            writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
            describeContents = function (){}
            getInputType = function (){}
            getImeOptions = function (){}
            getVoiceSearchLaunchRecognizer = function (){}
            shouldRewriteQueryFromText = function (){}
            getSuggestAuthority = function (){}
            shouldRewriteQueryFromData = function (){}
            getSuggestIntentAction = function (){}
            getVoiceSearchLaunchWebSearch = function (){}
            getVoiceLanguageModeId = function (){}
            getSettingsDescriptionId = function (){}
            getSuggestIntentData = function (){}
            getSuggestThreshold = function (){}
            getVoiceSearchEnabled = function (){}
            getSuggestSelection = function (){}
            getVoicePromptTextId = function (){}
            shouldIncludeInGlobalSearch = function (){}
            queryAfterZeroResults = function (){}
            getSuggestPackage = function (){}
            getSuggestPath = function (){}
            autoUrlDetect = function (){}
            getVoiceLanguageId = function (){}
            getVoiceMaxResults = function (){}
            getHintId = function (){}
            getSearchActivity = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
