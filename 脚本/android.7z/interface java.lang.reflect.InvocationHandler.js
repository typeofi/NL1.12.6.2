var java = {
    lang: {
        reflect: {
            InvocationHandler: class {
                invoke = function (arg0/*Object*/, arg1/*Method*/, arg2/*Object[]*/){}
            }
        }
    }
}
