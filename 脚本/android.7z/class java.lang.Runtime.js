var java = {
    lang: {
        Runtime: class {
            exit = function (arg0/*int*/){}
            runFinalization = function (){}
            static version = function (){}
            loadLibrary = function (arg0/*String*/){}
            gc = function (){}
            load = function (arg0/*String*/){}
            static getRuntime = function (){}
            freeMemory = function (){}
            availableProcessors = function (){}
            addShutdownHook = function (arg0/*Thread*/){}
            removeShutdownHook = function (arg0/*Thread*/){}
            halt = function (arg0/*int*/){}
            exec = function (arg0/*String*/){}
            exec = function (arg0/*String[]*/, arg1/*String[]*/){}
            exec = function (arg0/*String[]*/){}
            exec = function (arg0/*String*/, arg1/*String[]*/, arg2/*File*/){}
            exec = function (arg0/*String[]*/, arg1/*String[]*/, arg2/*File*/){}
            exec = function (arg0/*String*/, arg1/*String[]*/){}
            totalMemory = function (){}
            maxMemory = function (){}
            traceInstructions = function (arg0/*boolean*/){}
            traceMethodCalls = function (arg0/*boolean*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
