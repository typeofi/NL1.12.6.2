var android = {
    app: {
        backup: {
            BackupHelper: class {
                writeNewStateDescription = function (arg0/*ParcelFileDescriptor*/){}
                restoreEntity = function (arg0/*BackupDataInputStream*/){}
                performBackup = function (arg0/*ParcelFileDescriptor*/, arg1/*BackupDataOutput*/, arg2/*ParcelFileDescriptor*/){}
            }
        }
    }
}
