var android = {
    app: {
        slice: {
            SliceProvider: class {
                update = function (arg0/*Uri*/, arg1/*ContentValues*/, arg2/*String*/, arg3/*String[]*/){}
                delete = function (arg0/*Uri*/, arg1/*String*/, arg2/*String[]*/){}
                getType = function (arg0/*Uri*/){}
                insert = function (arg0/*Uri*/, arg1/*ContentValues*/){}
                query = function (arg0/*Uri*/, arg1/*String[]*/, arg2/*Bundle*/, arg3/*CancellationSignal*/){}
                query = function (arg0/*Uri*/, arg1/*String[]*/, arg2/*String*/, arg3/*String[]*/, arg4/*String*/){}
                query = function (arg0/*Uri*/, arg1/*String[]*/, arg2/*String*/, arg3/*String[]*/, arg4/*String*/, arg5/*CancellationSignal*/){}
                call = function (arg0/*String*/, arg1/*String*/, arg2/*Bundle*/){}
                attachInfo = function (arg0/*Context*/, arg1/*ProviderInfo*/){}
                onMapIntentToUri = function (arg0/*Intent*/){}
                onSlicePinned = function (arg0/*Uri*/){}
                onBindSlice = function (arg0/*Uri*/, arg1/*Set*/){}
                onSliceUnpinned = function (arg0/*Uri*/){}
                onGetSliceDescendants = function (arg0/*Uri*/){}
                onCreatePermissionRequest = function (arg0/*Uri*/){}
                shutdown = function (){}
                update = function (arg0/*Uri*/, arg1/*ContentValues*/, arg2/*Bundle*/){}
                delete = function (arg0/*Uri*/, arg1/*Bundle*/){}
                getContext = function (){}
                insert = function (arg0/*Uri*/, arg1/*ContentValues*/, arg2/*Bundle*/){}
                canonicalize = function (arg0/*Uri*/){}
                call = function (arg0/*String*/, arg1/*String*/, arg2/*String*/, arg3/*Bundle*/){}
                dump = function (arg0/*FileDescriptor*/, arg1/*PrintWriter*/, arg2/*String[]*/){}
                getCallingPackage = function (){}
                onLowMemory = function (){}
                onCreate = function (){}
                onTrimMemory = function (arg0/*int*/){}
                onConfigurationChanged = function (arg0/*Configuration*/){}
                requireContext = function (){}
                getWritePermission = function (){}
                getReadPermission = function (){}
                openPipeHelper = function (arg0/*Uri*/, arg1/*String*/, arg2/*Bundle*/, arg3/*Object*/, arg4/*PipeDataWriter*/){}
                getPathPermissions = function (){}
                bulkInsert = function (arg0/*Uri*/, arg1/*ContentValues[]*/){}
                openAssetFile = function (arg0/*Uri*/, arg1/*String*/, arg2/*CancellationSignal*/){}
                openAssetFile = function (arg0/*Uri*/, arg1/*String*/){}
                openTypedAssetFile = function (arg0/*Uri*/, arg1/*String*/, arg2/*Bundle*/){}
                openTypedAssetFile = function (arg0/*Uri*/, arg1/*String*/, arg2/*Bundle*/, arg3/*CancellationSignal*/){}
                applyBatch = function (arg0/*ArrayList*/){}
                applyBatch = function (arg0/*String*/, arg1/*ArrayList*/){}
                getStreamTypes = function (arg0/*Uri*/, arg1/*String*/){}
                refresh = function (arg0/*Uri*/, arg1/*Bundle*/, arg2/*CancellationSignal*/){}
                uncanonicalize = function (arg0/*Uri*/){}
                openFile = function (arg0/*Uri*/, arg1/*String*/){}
                openFile = function (arg0/*Uri*/, arg1/*String*/, arg2/*CancellationSignal*/){}
                restoreCallingIdentity = function (arg0/*CallingIdentity*/){}
                getCallingAttributionTag = function (){}
                getCallingPackageUnchecked = function (){}
                onCallingPackageChanged = function (){}
                clearCallingIdentity = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
