var java = {
    lang: {
        invoke: {
            MethodHandleInfo: class {
                static toString = function (arg0/*int*/, arg1/*Class*/, arg2/*String*/, arg3/*MethodType*/){}
                getModifiers = function (){}
                getName = function (){}
                getDeclaringClass = function (){}
                isVarArgs = function (){}
                getReferenceKind = function (){}
                getMethodType = function (){}
                reflectAs = function (arg0/*Class*/, arg1/*Lookup*/){}
                static referenceKindToString = function (arg0/*int*/){}
            }
        }
    }
}
