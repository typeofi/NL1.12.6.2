var android = {
    widget: {
        MultiAutoCompleteTextView: {
            CommaTokenizer: class {
                terminateToken = function (arg0/*CharSequence*/){}
                findTokenEnd = function (arg0/*CharSequence*/, arg1/*int*/){}
                findTokenStart = function (arg0/*CharSequence*/, arg1/*int*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
