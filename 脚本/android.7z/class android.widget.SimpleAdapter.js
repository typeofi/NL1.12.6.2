var android = {
    widget: {
        SimpleAdapter: class {
            getCount = function (){}
            getFilter = function (){}
            getDropDownView = function (arg0/*int*/, arg1/*View*/, arg2/*ViewGroup*/){}
            getView = function (arg0/*int*/, arg1/*View*/, arg2/*ViewGroup*/){}
            getItem = function (arg0/*int*/){}
            getItemId = function (arg0/*int*/){}
            setViewText = function (arg0/*TextView*/, arg1/*String*/){}
            getViewBinder = function (){}
            setViewBinder = function (arg0/*ViewBinder*/){}
            setViewImage = function (arg0/*ImageView*/, arg1/*int*/){}
            setViewImage = function (arg0/*ImageView*/, arg1/*String*/){}
            setDropDownViewTheme = function (arg0/*Theme*/){}
            setDropDownViewResource = function (arg0/*int*/){}
            getDropDownViewTheme = function (){}
            isEmpty = function (){}
            isEnabled = function (arg0/*int*/){}
            getAutofillOptions = function (){}
            hasStableIds = function (){}
            getViewTypeCount = function (){}
            getItemViewType = function (arg0/*int*/){}
            unregisterDataSetObserver = function (arg0/*DataSetObserver*/){}
            registerDataSetObserver = function (arg0/*DataSetObserver*/){}
            areAllItemsEnabled = function (){}
            notifyDataSetChanged = function (){}
            notifyDataSetInvalidated = function (){}
            setAutofillOptions = function (arg0/*CharSequence[]*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
