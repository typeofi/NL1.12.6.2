var java = {
    lang: {
        Runnable: class {
            run = function (){}
        }
    }
}
