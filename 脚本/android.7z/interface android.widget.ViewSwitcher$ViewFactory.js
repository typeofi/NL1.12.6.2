var android = {
    widget: {
        ViewSwitcher: {
            ViewFactory: class {
                makeView = function (){}
            }
        }
    }
}
