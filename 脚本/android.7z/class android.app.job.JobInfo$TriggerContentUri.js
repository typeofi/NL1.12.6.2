var android = {
    app: {
        job: {
            JobInfo: {
                TriggerContentUri: class {
                    equals = function (arg0/*Object*/){}
                    hashCode = function (){}
                    getFlags = function (){}
                    writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                    describeContents = function (){}
                    getUri = function (){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    toString = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
