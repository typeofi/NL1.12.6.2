var android = {
    widget: {
        SeekBar: {
            OnSeekBarChangeListener: class {
                onProgressChanged = function (arg0/*SeekBar*/, arg1/*int*/, arg2/*boolean*/){}
                onStartTrackingTouch = function (arg0/*SeekBar*/){}
                onStopTrackingTouch = function (arg0/*SeekBar*/){}
            }
        }
    }
}
