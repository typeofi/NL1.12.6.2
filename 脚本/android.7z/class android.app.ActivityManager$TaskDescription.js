var android = {
    app: {
        ActivityManager: {
            TaskDescription: class {
                equals = function (arg0/*Object*/){}
                toString = function (){}
                getIcon = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                readFromParcel = function (arg0/*Parcel*/){}
                getPrimaryColor = function (){}
                getLabel = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
