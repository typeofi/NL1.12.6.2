var java = {
    io: {
        ObjectOutputStream: class {
            write = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            write = function (arg0/*byte[]*/){}
            write = function (arg0/*int*/){}
            writeObject = function (arg0/*Object*/){}
            defaultWriteObject = function (){}
            flush = function (){}
            close = function (){}
            writeInt = function (arg0/*int*/){}
            putFields = function (){}
            writeFields = function (){}
            reset = function (){}
            writeBytes = function (arg0/*String*/){}
            writeUTF = function (arg0/*String*/){}
            writeFloat = function (arg0/*float*/){}
            writeChar = function (arg0/*int*/){}
            writeBoolean = function (arg0/*boolean*/){}
            writeByte = function (arg0/*int*/){}
            writeShort = function (arg0/*int*/){}
            writeLong = function (arg0/*long*/){}
            writeDouble = function (arg0/*double*/){}
            writeChars = function (arg0/*String*/){}
            useProtocolVersion = function (arg0/*int*/){}
            writeUnshared = function (arg0/*Object*/){}
            static nullOutputStream = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
