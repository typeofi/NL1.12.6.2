var android = {
    widget: {
        GridLayout: {
            Spec: class {
                equals = function (arg0/*Object*/){}
                hashCode = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                toString = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
