var android = {
    app: {
        ActionBar: {
            OnMenuVisibilityListener: class {
                onMenuVisibilityChanged = function (arg0/*boolean*/){}
            }
        }
    }
}
