var java = {
    lang: {
        Override: class {
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            annotationType = function (){}
        }
    }
}
