var android = {
    app: {
        assist: {
            AssistStructure: {
                ViewNode: class {
                    getId = function (){}
                    isOpaque = function (){}
                    getClassName = function (){}
                    getChildCount = function (){}
                    isEnabled = function (){}
                    getText = function (){}
                    getContentDescription = function (){}
                    getAlpha = function (){}
                    getAutofillType = function (){}
                    getAutofillId = function (){}
                    getAutofillHints = function (){}
                    getAutofillValue = function (){}
                    isFocused = function (){}
                    getVisibility = function (){}
                    isContextClickable = function (){}
                    isClickable = function (){}
                    isFocusable = function (){}
                    isLongClickable = function (){}
                    getScrollX = function (){}
                    getScrollY = function (){}
                    getWidth = function (){}
                    getHeight = function (){}
                    getElevation = function (){}
                    getTop = function (){}
                    getLeft = function (){}
                    isActivated = function (){}
                    isSelected = function (){}
                    getAutofillOptions = function (){}
                    getExtras = function (){}
                    getChildAt = function (arg0/*int*/){}
                    isChecked = function (){}
                    isCheckable = function (){}
                    getImportantForAutofill = function (){}
                    isAccessibilityFocused = function (){}
                    getHint = function (){}
                    getInputType = function (){}
                    getTextSize = function (){}
                    getIdPackage = function (){}
                    getIdType = function (){}
                    getMaxTextEms = function (){}
                    getHintIdEntry = function (){}
                    getTextColor = function (){}
                    getTransformation = function (){}
                    getWebDomain = function (){}
                    getWebScheme = function (){}
                    isAssistBlocked = function (){}
                    getHtmlInfo = function (){}
                    getMaxTextLength = function (){}
                    getLocaleList = function (){}
                    getTextStyle = function (){}
                    getMinTextEms = function (){}
                    getTextIdEntry = function (){}
                    getIdEntry = function (){}
                    getTextBackgroundColor = function (){}
                    getTextLineBaselines = function (){}
                    getTextSelectionStart = function (){}
                    getTextSelectionEnd = function (){}
                    getTextLineCharOffsets = function (){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    equals = function (arg0/*Object*/){}
                    toString = function (){}
                    hashCode = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
