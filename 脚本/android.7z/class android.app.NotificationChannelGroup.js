var android = {
    app: {
        NotificationChannelGroup: class {
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            clone = function (){}
            clone = function (){}
            getName = function (){}
            getId = function (){}
            getDescription = function (){}
            writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
            describeContents = function (){}
            setDescription = function (arg0/*String*/){}
            isBlocked = function (){}
            getChannels = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
