var android = {
    widget: {
        RadioGroup: {
            OnCheckedChangeListener: class {
                onCheckedChanged = function (arg0/*RadioGroup*/, arg1/*int*/){}
            }
        }
    }
}
