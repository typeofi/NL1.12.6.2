var android = {
    app: {
        Notification: {
            CarExtender: {
                Builder: class {
                    build = function (){}
                    setReadPendingIntent = function (arg0/*PendingIntent*/){}
                    addMessage = function (arg0/*String*/){}
                    setReplyAction = function (arg0/*PendingIntent*/, arg1/*RemoteInput*/){}
                    setLatestTimestamp = function (arg0/*long*/){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    equals = function (arg0/*Object*/){}
                    toString = function (){}
                    hashCode = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
