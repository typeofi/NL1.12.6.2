var java = {
    lang: {
        RuntimePermission: class {
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            implies = function (arg0/*Permission*/){}
            getActions = function (){}
            newPermissionCollection = function (){}
            toString = function (){}
            getName = function (){}
            checkGuard = function (arg0/*Object*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
