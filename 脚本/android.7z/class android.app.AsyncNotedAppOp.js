var android = {
    app: {
        AsyncNotedAppOp: class {
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getMessage = function (){}
            getTime = function (){}
            getAttributionTag = function (){}
            writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
            describeContents = function (){}
            getOp = function (){}
            getNotingUid = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            toString = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
