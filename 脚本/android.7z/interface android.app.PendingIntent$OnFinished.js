var android = {
    app: {
        PendingIntent: {
            OnFinished: class {
                onSendFinished = function (arg0/*PendingIntent*/, arg1/*Intent*/, arg2/*int*/, arg3/*String*/, arg4/*Bundle*/){}
            }
        }
    }
}
