var java = {
    lang: {
        Double: class {
            equals = function (arg0/*Object*/){}
            static toString = function (arg0/*double*/){}
            toString = function (){}
            hashCode = function (){}
            static hashCode = function (arg0/*double*/){}
            static min = function (arg0/*double*/, arg1/*double*/){}
            static max = function (arg0/*double*/, arg1/*double*/){}
            static doubleToRawLongBits = function (arg0/*double*/){}
            static doubleToLongBits = function (arg0/*double*/){}
            static longBitsToDouble = function (arg0/*long*/){}
            compareTo = function (arg0/*Object*/){}
            compareTo = function (arg0/*Double*/){}
            byteValue = function (){}
            shortValue = function (){}
            intValue = function (){}
            longValue = function (){}
            floatValue = function (){}
            doubleValue = function (){}
            static valueOf = function (arg0/*String*/){}
            static valueOf = function (arg0/*double*/){}
            static toHexString = function (arg0/*double*/){}
            static compare = function (arg0/*double*/, arg1/*double*/){}
            static isNaN = function (arg0/*double*/){}
            isNaN = function (){}
            static isInfinite = function (arg0/*double*/){}
            isInfinite = function (){}
            static isFinite = function (arg0/*double*/){}
            static sum = function (arg0/*double*/, arg1/*double*/){}
            static parseDouble = function (arg0/*String*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
