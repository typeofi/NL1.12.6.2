var android = {
    widget: {
        PopupMenu: {
            OnMenuItemClickListener: class {
                onMenuItemClick = function (arg0/*MenuItem*/){}
            }
        }
    }
}
