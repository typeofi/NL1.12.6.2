var android = {
    widget: {
        ZoomButtonsController: {
            OnZoomListener: class {
                onVisibilityChanged = function (arg0/*boolean*/){}
                onZoom = function (arg0/*boolean*/){}
            }
        }
    }
}
