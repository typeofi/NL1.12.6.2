var android = {
    widget: {
        ResourceCursorTreeAdapter: class {
            newChildView = function (arg0/*Context*/, arg1/*Cursor*/, arg2/*boolean*/, arg3/*ViewGroup*/){}
            newGroupView = function (arg0/*Context*/, arg1/*Cursor*/, arg2/*boolean*/, arg3/*ViewGroup*/){}
            getFilter = function (){}
            getChild = function (arg0/*int*/, arg1/*int*/){}
            getChild = function (arg0/*int*/, arg1/*int*/){}
            hasStableIds = function (){}
            getGroupId = function (arg0/*int*/){}
            setGroupCursor = function (arg0/*Cursor*/){}
            setChildrenCursor = function (arg0/*int*/, arg1/*Cursor*/){}
            convertToString = function (arg0/*Cursor*/){}
            getCursor = function (){}
            changeCursor = function (arg0/*Cursor*/){}
            getGroup = function (arg0/*int*/){}
            getGroup = function (arg0/*int*/){}
            getChildrenCount = function (arg0/*int*/){}
            getGroupCount = function (){}
            getChildId = function (arg0/*int*/, arg1/*int*/){}
            getGroupView = function (arg0/*int*/, arg1/*boolean*/, arg2/*View*/, arg3/*ViewGroup*/){}
            onGroupCollapsed = function (arg0/*int*/){}
            getChildView = function (arg0/*int*/, arg1/*int*/, arg2/*boolean*/, arg3/*View*/, arg4/*ViewGroup*/){}
            isChildSelectable = function (arg0/*int*/, arg1/*int*/){}
            notifyDataSetChanged = function (arg0/*boolean*/){}
            notifyDataSetChanged = function (){}
            notifyDataSetInvalidated = function (){}
            runQueryOnBackgroundThread = function (arg0/*CharSequence*/){}
            getFilterQueryProvider = function (){}
            setFilterQueryProvider = function (arg0/*FilterQueryProvider*/){}
            isEmpty = function (){}
            unregisterDataSetObserver = function (arg0/*DataSetObserver*/){}
            registerDataSetObserver = function (arg0/*DataSetObserver*/){}
            getChildType = function (arg0/*int*/, arg1/*int*/){}
            getGroupTypeCount = function (){}
            getChildTypeCount = function (){}
            getGroupType = function (arg0/*int*/){}
            areAllItemsEnabled = function (){}
            getCombinedChildId = function (arg0/*long*/, arg1/*long*/){}
            getCombinedGroupId = function (arg0/*long*/){}
            onGroupExpanded = function (arg0/*int*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
