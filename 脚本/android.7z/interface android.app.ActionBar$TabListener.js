var android = {
    app: {
        ActionBar: {
            TabListener: class {
                onTabUnselected = function (arg0/*Tab*/, arg1/*FragmentTransaction*/){}
                onTabReselected = function (arg0/*Tab*/, arg1/*FragmentTransaction*/){}
                onTabSelected = function (arg0/*Tab*/, arg1/*FragmentTransaction*/){}
            }
        }
    }
}
