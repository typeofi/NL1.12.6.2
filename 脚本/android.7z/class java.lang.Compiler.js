var java = {
    lang: {
        Compiler: class {
            static command = function (arg0/*Object*/){}
            static enable = function (){}
            static compileClass = function (arg0/*Class*/){}
            static compileClasses = function (arg0/*String*/){}
            static disable = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
