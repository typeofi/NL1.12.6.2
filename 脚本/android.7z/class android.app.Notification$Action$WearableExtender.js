var android = {
    app: {
        Notification: {
            Action: {
                WearableExtender: class {
                    clone = function (){}
                    clone = function (){}
                    setAvailableOffline = function (arg0/*boolean*/){}
                    setHintLaunchesActivity = function (arg0/*boolean*/){}
                    getHintLaunchesActivity = function (){}
                    setHintDisplayActionInline = function (arg0/*boolean*/){}
                    getHintDisplayActionInline = function (){}
                    setCancelLabel = function (arg0/*CharSequence*/){}
                    getInProgressLabel = function (){}
                    getCancelLabel = function (){}
                    setConfirmLabel = function (arg0/*CharSequence*/){}
                    extend = function (arg0/*Builder*/){}
                    isAvailableOffline = function (){}
                    setInProgressLabel = function (arg0/*CharSequence*/){}
                    getConfirmLabel = function (){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    equals = function (arg0/*Object*/){}
                    toString = function (){}
                    hashCode = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
