var java = {
    io: {
        InputStreamReader: class {
            read = function (){}
            read = function (arg0/*char[]*/, arg1/*int*/, arg2/*int*/){}
            close = function (){}
            getEncoding = function (){}
            ready = function (){}
            read = function (arg0/*char[]*/){}
            read = function (arg0/*CharBuffer*/){}
            mark = function (arg0/*int*/){}
            transferTo = function (arg0/*Writer*/){}
            skip = function (arg0/*long*/){}
            markSupported = function (){}
            reset = function (){}
            static nullReader = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
