var java = {
    lang: {
        reflect: {
            Parameter: class {
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getModifiers = function (){}
                getName = function (){}
                isSynthetic = function (){}
                getAnnotation = function (arg0/*Class*/){}
                getAnnotationsByType = function (arg0/*Class*/){}
                getAnnotations = function (){}
                getDeclaredAnnotation = function (arg0/*Class*/){}
                getDeclaredAnnotationsByType = function (arg0/*Class*/){}
                getDeclaredAnnotations = function (){}
                getType = function (){}
                getAnnotatedType = function (){}
                isNamePresent = function (){}
                getDeclaringExecutable = function (){}
                getParameterizedType = function (){}
                isImplicit = function (){}
                isVarArgs = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
                isAnnotationPresent = function (arg0/*Class*/){}
            }
        }
    }
}
