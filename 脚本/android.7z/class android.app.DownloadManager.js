var android = {
    app: {
        DownloadManager: class {
            remove = function (arg0/*long[]*/){}
            enqueue = function (arg0/*Request*/){}
            query = function (arg0/*Query*/){}
            openDownloadedFile = function (arg0/*long*/){}
            static getRecommendedMaxBytesOverMobile = function (arg0/*Context*/){}
            static getMaxBytesOverMobile = function (arg0/*Context*/){}
            getMimeTypeForDownloadedFile = function (arg0/*long*/){}
            addCompletedDownload = function (arg0/*String*/, arg1/*String*/, arg2/*boolean*/, arg3/*String*/, arg4/*String*/, arg5/*long*/, arg6/*boolean*/){}
            addCompletedDownload = function (arg0/*String*/, arg1/*String*/, arg2/*boolean*/, arg3/*String*/, arg4/*String*/, arg5/*long*/, arg6/*boolean*/, arg7/*Uri*/, arg8/*Uri*/){}
            getUriForDownloadedFile = function (arg0/*long*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
