var java = {
    io: {
        WriteAbortedException: class {
            getCause = function (){}
            getMessage = function (){}
            printStackTrace = function (arg0/*PrintStream*/){}
            printStackTrace = function (){}
            printStackTrace = function (arg0/*PrintWriter*/){}
            fillInStackTrace = function (){}
            initCause = function (arg0/*Throwable*/){}
            toString = function (){}
            getSuppressed = function (){}
            getLocalizedMessage = function (){}
            getStackTrace = function (){}
            setStackTrace = function (arg0/*StackTraceElement[]*/){}
            addSuppressed = function (arg0/*Throwable*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
