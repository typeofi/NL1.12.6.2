var android = {
    app: {
        ActivityManager: class {
            getMemoryInfo = function (arg0/*MemoryInfo*/){}
            getAppTaskThumbnailSize = function (){}
            clearApplicationUserData = function (){}
            clearWatchHeapLimit = function (){}
            getLauncherLargeIconSize = function (){}
            getProcessMemoryInfo = function (arg0/*int[]*/){}
            isActivityStartAllowedOnDisplay = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent*/){}
            getRunningServiceControlPanel = function (arg0/*ComponentName*/){}
            getProcessesInErrorState = function (){}
            killBackgroundProcesses = function (arg0/*String*/){}
            getHistoricalProcessExitReasons = function (arg0/*String*/, arg1/*int*/, arg2/*int*/){}
            getLauncherLargeIconDensity = function (){}
            static isRunningInTestHarness = function (){}
            getRunningAppProcesses = function (){}
            getDeviceConfigurationInfo = function (){}
            setProcessStateSummary = function (arg0/*byte[]*/){}
            static isRunningInUserTestHarness = function (){}
            getLockTaskModeState = function (){}
            getLargeMemoryClass = function (){}
            static isLowMemoryKillReportSupported = function (){}
            isBackgroundRestricted = function (){}
            restartPackage = function (arg0/*String*/){}
            static isUserAMonkey = function (){}
            setWatchHeapLimit = function (arg0/*long*/){}
            static setVrThread = function (arg0/*int*/){}
            getAppTasks = function (){}
            getMemoryClass = function (){}
            isInLockTaskMode = function (){}
            dumpPackageState = function (arg0/*FileDescriptor*/, arg1/*String*/){}
            moveTaskToFront = function (arg0/*int*/, arg1/*int*/, arg2/*Bundle*/){}
            moveTaskToFront = function (arg0/*int*/, arg1/*int*/){}
            getRunningServices = function (arg0/*int*/){}
            addAppTask = function (arg0/*Activity*/, arg1/*Intent*/, arg2/*TaskDescription*/, arg3/*Bitmap*/){}
            appNotResponding = function (arg0/*String*/){}
            getRecentTasks = function (arg0/*int*/, arg1/*int*/){}
            getRunningTasks = function (arg0/*int*/){}
            isLowRamDevice = function (){}
            static getMyMemoryState = function (arg0/*RunningAppProcessInfo*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
