var android = {
    app: {
        admin: {
            DeviceAdminReceiver: class {
                onTransferAffiliatedProfileOwnershipComplete = function (arg0/*Context*/, arg1/*UserHandle*/){}
                onUserStarted = function (arg0/*Context*/, arg1/*Intent*/, arg2/*UserHandle*/){}
                onUserAdded = function (arg0/*Context*/, arg1/*Intent*/, arg2/*UserHandle*/){}
                onPasswordExpiring = function (arg0/*Context*/, arg1/*Intent*/){}
                onPasswordExpiring = function (arg0/*Context*/, arg1/*Intent*/, arg2/*UserHandle*/){}
                onUserRemoved = function (arg0/*Context*/, arg1/*Intent*/, arg2/*UserHandle*/){}
                onBugreportFailed = function (arg0/*Context*/, arg1/*Intent*/, arg2/*int*/){}
                onUserSwitched = function (arg0/*Context*/, arg1/*Intent*/, arg2/*UserHandle*/){}
                onBugreportShared = function (arg0/*Context*/, arg1/*Intent*/, arg2/*String*/){}
                onUserStopped = function (arg0/*Context*/, arg1/*Intent*/, arg2/*UserHandle*/){}
                getManager = function (arg0/*Context*/){}
                getWho = function (arg0/*Context*/){}
                onEnabled = function (arg0/*Context*/, arg1/*Intent*/){}
                onDisableRequested = function (arg0/*Context*/, arg1/*Intent*/){}
                onDisabled = function (arg0/*Context*/, arg1/*Intent*/){}
                onPasswordChanged = function (arg0/*Context*/, arg1/*Intent*/){}
                onPasswordChanged = function (arg0/*Context*/, arg1/*Intent*/, arg2/*UserHandle*/){}
                onPasswordFailed = function (arg0/*Context*/, arg1/*Intent*/, arg2/*UserHandle*/){}
                onPasswordFailed = function (arg0/*Context*/, arg1/*Intent*/){}
                onReceive = function (arg0/*Context*/, arg1/*Intent*/){}
                onNetworkLogsAvailable = function (arg0/*Context*/, arg1/*Intent*/, arg2/*long*/, arg3/*int*/){}
                onChoosePrivateKeyAlias = function (arg0/*Context*/, arg1/*Intent*/, arg2/*int*/, arg3/*Uri*/, arg4/*String*/){}
                onLockTaskModeExiting = function (arg0/*Context*/, arg1/*Intent*/){}
                onTransferOwnershipComplete = function (arg0/*Context*/, arg1/*PersistableBundle*/){}
                onLockTaskModeEntering = function (arg0/*Context*/, arg1/*Intent*/, arg2/*String*/){}
                onBugreportSharingDeclined = function (arg0/*Context*/, arg1/*Intent*/){}
                onSecurityLogsAvailable = function (arg0/*Context*/, arg1/*Intent*/){}
                onSystemUpdatePending = function (arg0/*Context*/, arg1/*Intent*/, arg2/*long*/){}
                onPasswordSucceeded = function (arg0/*Context*/, arg1/*Intent*/){}
                onPasswordSucceeded = function (arg0/*Context*/, arg1/*Intent*/, arg2/*UserHandle*/){}
                onReadyForUserInitialization = function (arg0/*Context*/, arg1/*Intent*/){}
                onProfileProvisioningComplete = function (arg0/*Context*/, arg1/*Intent*/){}
                setResult = function (arg0/*int*/, arg1/*String*/, arg2/*Bundle*/){}
                clearAbortBroadcast = function (){}
                isInitialStickyBroadcast = function (){}
                setResultExtras = function (arg0/*Bundle*/){}
                getAbortBroadcast = function (){}
                getDebugUnregister = function (){}
                setDebugUnregister = function (arg0/*boolean*/){}
                getResultCode = function (){}
                isOrderedBroadcast = function (){}
                setOrderedHint = function (arg0/*boolean*/){}
                getResultData = function (){}
                getResultExtras = function (arg0/*boolean*/){}
                setResultData = function (arg0/*String*/){}
                goAsync = function (){}
                abortBroadcast = function (){}
                peekService = function (arg0/*Context*/, arg1/*Intent*/){}
                setResultCode = function (arg0/*int*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
