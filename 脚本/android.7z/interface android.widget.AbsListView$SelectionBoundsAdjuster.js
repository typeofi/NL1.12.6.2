var android = {
    widget: {
        AbsListView: {
            SelectionBoundsAdjuster: class {
                adjustListItemSelectionBounds = function (arg0/*Rect*/){}
            }
        }
    }
}
