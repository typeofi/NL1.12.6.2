var java = {
    lang: {
        reflect: {
            GenericDeclaration: class {
                getTypeParameters = function (){}
                getAnnotation = function (arg0/*Class*/){}
                isAnnotationPresent = function (arg0/*Class*/){}
                getAnnotationsByType = function (arg0/*Class*/){}
                getAnnotations = function (){}
                getDeclaredAnnotation = function (arg0/*Class*/){}
                getDeclaredAnnotationsByType = function (arg0/*Class*/){}
                getDeclaredAnnotations = function (){}
            }
        }
    }
}
