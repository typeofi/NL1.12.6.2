var android = {
    app: {
        ZygotePreload: class {
            doPreload = function (arg0/*ApplicationInfo*/){}
        }
    }
}
