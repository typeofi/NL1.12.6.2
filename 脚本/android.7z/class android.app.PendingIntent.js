var android = {
    app: {
        PendingIntent: class {
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            static getService = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent*/, arg3/*int*/){}
            cancel = function (){}
            static getBroadcast = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent*/, arg3/*int*/){}
            send = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent*/){}
            send = function (arg0/*int*/, arg1/*OnFinished*/, arg2/*Handler*/){}
            send = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent*/, arg3/*OnFinished*/, arg4/*Handler*/){}
            send = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent*/, arg3/*OnFinished*/, arg4/*Handler*/, arg5/*String*/, arg6/*Bundle*/){}
            send = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent*/, arg3/*OnFinished*/, arg4/*Handler*/, arg5/*String*/){}
            send = function (){}
            send = function (arg0/*int*/){}
            writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
            describeContents = function (){}
            getTargetPackage = function (){}
            getCreatorPackage = function (){}
            getCreatorUid = function (){}
            static getActivity = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent*/, arg3/*int*/, arg4/*Bundle*/){}
            static getActivity = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent*/, arg3/*int*/){}
            static getActivities = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent[]*/, arg3/*int*/, arg4/*Bundle*/){}
            static getActivities = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent[]*/, arg3/*int*/){}
            getIntentSender = function (){}
            getCreatorUserHandle = function (){}
            static writePendingIntentOrNullToParcel = function (arg0/*PendingIntent*/, arg1/*Parcel*/){}
            static getForegroundService = function (arg0/*Context*/, arg1/*int*/, arg2/*Intent*/, arg3/*int*/){}
            static readPendingIntentOrNullFromParcel = function (arg0/*Parcel*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
