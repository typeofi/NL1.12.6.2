var android = {
    app: {
        AppOpsManager: {
            OnOpActiveChangedListener: class {
                onOpActiveChanged = function (arg0/*String*/, arg1/*int*/, arg2/*String*/, arg3/*boolean*/){}
            }
        }
    }
}
