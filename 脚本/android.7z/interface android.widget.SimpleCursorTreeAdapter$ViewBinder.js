var android = {
    widget: {
        SimpleCursorTreeAdapter: {
            ViewBinder: class {
                setViewValue = function (arg0/*View*/, arg1/*Cursor*/, arg2/*int*/){}
            }
        }
    }
}
