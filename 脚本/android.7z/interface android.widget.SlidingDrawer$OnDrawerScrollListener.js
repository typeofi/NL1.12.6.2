var android = {
    widget: {
        SlidingDrawer: {
            OnDrawerScrollListener: class {
                onScrollEnded = function (){}
                onScrollStarted = function (){}
            }
        }
    }
}
