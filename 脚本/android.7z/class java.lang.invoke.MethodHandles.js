var java = {
    lang: {
        invoke: {
            MethodHandles: class {
                static empty = function (arg0/*MethodType*/){}
                static constant = function (arg0/*Class*/, arg1/*Object*/){}
                static throwException = function (arg0/*Class*/, arg1/*Class*/){}
                static identity = function (arg0/*Class*/){}
                static arrayLength = function (arg0/*Class*/){}
                static spreadInvoker = function (arg0/*MethodType*/, arg1/*int*/){}
                static varHandleInvoker = function (arg0/*AccessMode*/, arg1/*MethodType*/){}
                static lookup = function (){}
                static publicLookup = function (){}
                static zero = function (arg0/*Class*/){}
                static tryFinally = function (arg0/*MethodHandle*/, arg1/*MethodHandle*/){}
                static loop = function (arg0/*MethodHandle[][]*/){}
                static invoker = function (arg0/*MethodType*/){}
                static exactInvoker = function (arg0/*MethodType*/){}
                static foldArguments = function (arg0/*MethodHandle*/, arg1/*MethodHandle*/){}
                static foldArguments = function (arg0/*MethodHandle*/, arg1/*int*/, arg2/*MethodHandle*/){}
                static privateLookupIn = function (arg0/*Class*/, arg1/*Lookup*/){}
                static reflectAs = function (arg0/*Class*/, arg1/*MethodHandle*/){}
                static arrayConstructor = function (arg0/*Class*/){}
                static arrayElementGetter = function (arg0/*Class*/){}
                static arrayElementSetter = function (arg0/*Class*/){}
                static arrayElementVarHandle = function (arg0/*Class*/){}
                static byteArrayViewVarHandle = function (arg0/*Class*/, arg1/*ByteOrder*/){}
                static byteBufferViewVarHandle = function (arg0/*Class*/, arg1/*ByteOrder*/){}
                static varHandleExactInvoker = function (arg0/*AccessMode*/, arg1/*MethodType*/){}
                static explicitCastArguments = function (arg0/*MethodHandle*/, arg1/*MethodType*/){}
                static permuteArguments = function (arg0/*MethodHandle*/, arg1/*MethodType*/, arg2/*int[]*/){}
                static insertArguments = function (arg0/*MethodHandle*/, arg1/*int*/, arg2/*Object[]*/){}
                static dropArguments = function (arg0/*MethodHandle*/, arg1/*int*/, arg2/*List*/){}
                static dropArguments = function (arg0/*MethodHandle*/, arg1/*int*/, arg2/*Class[]*/){}
                static dropArgumentsToMatch = function (arg0/*MethodHandle*/, arg1/*int*/, arg2/*List*/, arg3/*int*/){}
                static filterArguments = function (arg0/*MethodHandle*/, arg1/*int*/, arg2/*MethodHandle[]*/){}
                static collectArguments = function (arg0/*MethodHandle*/, arg1/*int*/, arg2/*MethodHandle*/){}
                static filterReturnValue = function (arg0/*MethodHandle*/, arg1/*MethodHandle*/){}
                static guardWithTest = function (arg0/*MethodHandle*/, arg1/*MethodHandle*/, arg2/*MethodHandle*/){}
                static catchException = function (arg0/*MethodHandle*/, arg1/*Class*/, arg2/*MethodHandle*/){}
                static whileLoop = function (arg0/*MethodHandle*/, arg1/*MethodHandle*/, arg2/*MethodHandle*/){}
                static doWhileLoop = function (arg0/*MethodHandle*/, arg1/*MethodHandle*/, arg2/*MethodHandle*/){}
                static countedLoop = function (arg0/*MethodHandle*/, arg1/*MethodHandle*/, arg2/*MethodHandle*/, arg3/*MethodHandle*/){}
                static countedLoop = function (arg0/*MethodHandle*/, arg1/*MethodHandle*/, arg2/*MethodHandle*/){}
                static iteratedLoop = function (arg0/*MethodHandle*/, arg1/*MethodHandle*/, arg2/*MethodHandle*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
