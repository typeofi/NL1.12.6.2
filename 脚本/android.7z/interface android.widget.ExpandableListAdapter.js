var android = {
    widget: {
        ExpandableListAdapter: class {
            isEmpty = function (){}
            getChild = function (arg0/*int*/, arg1/*int*/){}
            hasStableIds = function (){}
            getGroupId = function (arg0/*int*/){}
            unregisterDataSetObserver = function (arg0/*DataSetObserver*/){}
            registerDataSetObserver = function (arg0/*DataSetObserver*/){}
            getGroup = function (arg0/*int*/){}
            getChildrenCount = function (arg0/*int*/){}
            getGroupCount = function (){}
            getChildId = function (arg0/*int*/, arg1/*int*/){}
            getGroupView = function (arg0/*int*/, arg1/*boolean*/, arg2/*View*/, arg3/*ViewGroup*/){}
            areAllItemsEnabled = function (){}
            onGroupCollapsed = function (arg0/*int*/){}
            getChildView = function (arg0/*int*/, arg1/*int*/, arg2/*boolean*/, arg3/*View*/, arg4/*ViewGroup*/){}
            getCombinedChildId = function (arg0/*long*/, arg1/*long*/){}
            getCombinedGroupId = function (arg0/*long*/){}
            isChildSelectable = function (arg0/*int*/, arg1/*int*/){}
            onGroupExpanded = function (arg0/*int*/){}
        }
    }
}
