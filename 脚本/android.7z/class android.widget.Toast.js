var android = {
    widget: {
        Toast: class {
            setText = function (arg0/*int*/){}
            setText = function (arg0/*CharSequence*/){}
            cancel = function (){}
            getDuration = function (){}
            show = function (){}
            getView = function (){}
            setGravity = function (arg0/*int*/, arg1/*int*/, arg2/*int*/){}
            addCallback = function (arg0/*Callback*/){}
            removeCallback = function (arg0/*Callback*/){}
            getGravity = function (){}
            setView = function (arg0/*View*/){}
            setDuration = function (arg0/*int*/){}
            getHorizontalMargin = function (){}
            getXOffset = function (){}
            getVerticalMargin = function (){}
            setMargin = function (arg0/*float*/, arg1/*float*/){}
            static makeText = function (arg0/*Context*/, arg1/*CharSequence*/, arg2/*int*/){}
            static makeText = function (arg0/*Context*/, arg1/*int*/, arg2/*int*/){}
            getYOffset = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
