var android = {
    app: {
        usage: {
            NetworkStatsManager: class {
                querySummary = function (arg0/*int*/, arg1/*String*/, arg2/*long*/, arg3/*long*/){}
                queryDetails = function (arg0/*int*/, arg1/*String*/, arg2/*long*/, arg3/*long*/){}
                queryDetailsForUid = function (arg0/*int*/, arg1/*String*/, arg2/*long*/, arg3/*long*/, arg4/*int*/){}
                queryDetailsForUidTagState = function (arg0/*int*/, arg1/*String*/, arg2/*long*/, arg3/*long*/, arg4/*int*/, arg5/*int*/, arg6/*int*/){}
                registerUsageCallback = function (arg0/*int*/, arg1/*String*/, arg2/*long*/, arg3/*UsageCallback*/){}
                registerUsageCallback = function (arg0/*int*/, arg1/*String*/, arg2/*long*/, arg3/*UsageCallback*/, arg4/*Handler*/){}
                querySummaryForUser = function (arg0/*int*/, arg1/*String*/, arg2/*long*/, arg3/*long*/){}
                queryDetailsForUidTag = function (arg0/*int*/, arg1/*String*/, arg2/*long*/, arg3/*long*/, arg4/*int*/, arg5/*int*/){}
                querySummaryForDevice = function (arg0/*int*/, arg1/*String*/, arg2/*long*/, arg3/*long*/){}
                unregisterUsageCallback = function (arg0/*UsageCallback*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
