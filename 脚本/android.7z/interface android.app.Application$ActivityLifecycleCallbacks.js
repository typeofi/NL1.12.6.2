var android = {
    app: {
        Application: {
            ActivityLifecycleCallbacks: class {
                onActivityCreated = function (arg0/*Activity*/, arg1/*Bundle*/){}
                onActivityPaused = function (arg0/*Activity*/){}
                onActivityStarted = function (arg0/*Activity*/){}
                onActivityStopped = function (arg0/*Activity*/){}
                onActivityResumed = function (arg0/*Activity*/){}
                onActivityPreStarted = function (arg0/*Activity*/){}
                onActivityPostStarted = function (arg0/*Activity*/){}
                onActivityPostResumed = function (arg0/*Activity*/){}
                onActivityPreCreated = function (arg0/*Activity*/, arg1/*Bundle*/){}
                onActivityPrePaused = function (arg0/*Activity*/){}
                onActivityDestroyed = function (arg0/*Activity*/){}
                onActivityPreSaveInstanceState = function (arg0/*Activity*/, arg1/*Bundle*/){}
                onActivitySaveInstanceState = function (arg0/*Activity*/, arg1/*Bundle*/){}
                onActivityPreDestroyed = function (arg0/*Activity*/){}
                onActivityPostSaveInstanceState = function (arg0/*Activity*/, arg1/*Bundle*/){}
                onActivityPostCreated = function (arg0/*Activity*/, arg1/*Bundle*/){}
                onActivityPostStopped = function (arg0/*Activity*/){}
                onActivityPreResumed = function (arg0/*Activity*/){}
                onActivityPostDestroyed = function (arg0/*Activity*/){}
                onActivityPostPaused = function (arg0/*Activity*/){}
                onActivityPreStopped = function (arg0/*Activity*/){}
            }
        }
    }
}
