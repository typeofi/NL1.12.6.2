var android = {
    app: {
        Notification: {
            InboxStyle: class {
                setBigContentTitle = function (arg0/*CharSequence*/){}
                setSummaryText = function (arg0/*CharSequence*/){}
                addLine = function (arg0/*CharSequence*/){}
                build = function (){}
                setBuilder = function (arg0/*Builder*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
