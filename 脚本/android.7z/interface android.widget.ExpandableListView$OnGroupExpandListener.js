var android = {
    widget: {
        ExpandableListView: {
            OnGroupExpandListener: class {
                onGroupExpand = function (arg0/*int*/){}
            }
        }
    }
}
