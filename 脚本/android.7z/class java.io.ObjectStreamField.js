var java = {
    io: {
        ObjectStreamField: class {
            toString = function (){}
            isPrimitive = function (){}
            compareTo = function (arg0/*Object*/){}
            getName = function (){}
            getType = function (){}
            getTypeCode = function (){}
            getTypeString = function (){}
            getOffset = function (){}
            isUnshared = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
