var android = {
    widget: {
        CursorAdapter: class {
            getCount = function (){}
            getFilter = function (){}
            hasStableIds = function (){}
            getDropDownView = function (arg0/*int*/, arg1/*View*/, arg2/*ViewGroup*/){}
            getView = function (arg0/*int*/, arg1/*View*/, arg2/*ViewGroup*/){}
            getItem = function (arg0/*int*/){}
            getItemId = function (arg0/*int*/){}
            newView = function (arg0/*Context*/, arg1/*Cursor*/, arg2/*ViewGroup*/){}
            bindView = function (arg0/*View*/, arg1/*Context*/, arg2/*Cursor*/){}
            convertToString = function (arg0/*Cursor*/){}
            swapCursor = function (arg0/*Cursor*/){}
            getCursor = function (){}
            changeCursor = function (arg0/*Cursor*/){}
            newDropDownView = function (arg0/*Context*/, arg1/*Cursor*/, arg2/*ViewGroup*/){}
            setDropDownViewTheme = function (arg0/*Theme*/){}
            getDropDownViewTheme = function (){}
            runQueryOnBackgroundThread = function (arg0/*CharSequence*/){}
            getFilterQueryProvider = function (){}
            setFilterQueryProvider = function (arg0/*FilterQueryProvider*/){}
            isEmpty = function (){}
            isEnabled = function (arg0/*int*/){}
            getAutofillOptions = function (){}
            getViewTypeCount = function (){}
            getItemViewType = function (arg0/*int*/){}
            unregisterDataSetObserver = function (arg0/*DataSetObserver*/){}
            registerDataSetObserver = function (arg0/*DataSetObserver*/){}
            areAllItemsEnabled = function (){}
            notifyDataSetChanged = function (){}
            notifyDataSetInvalidated = function (){}
            setAutofillOptions = function (arg0/*CharSequence[]*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
