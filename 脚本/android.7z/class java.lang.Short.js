var java = {
    lang: {
        Short: class {
            equals = function (arg0/*Object*/){}
            toString = function (){}
            static toString = function (arg0/*short*/){}
            hashCode = function (){}
            static hashCode = function (arg0/*short*/){}
            static reverseBytes = function (arg0/*short*/){}
            compareTo = function (arg0/*Short*/){}
            compareTo = function (arg0/*Object*/){}
            byteValue = function (){}
            shortValue = function (){}
            intValue = function (){}
            longValue = function (){}
            floatValue = function (){}
            doubleValue = function (){}
            static valueOf = function (arg0/*String*/, arg1/*int*/){}
            static valueOf = function (arg0/*String*/){}
            static valueOf = function (arg0/*short*/){}
            static decode = function (arg0/*String*/){}
            static compare = function (arg0/*short*/, arg1/*short*/){}
            static toUnsignedInt = function (arg0/*short*/){}
            static toUnsignedLong = function (arg0/*short*/){}
            static compareUnsigned = function (arg0/*short*/, arg1/*short*/){}
            static parseShort = function (arg0/*String*/, arg1/*int*/){}
            static parseShort = function (arg0/*String*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
