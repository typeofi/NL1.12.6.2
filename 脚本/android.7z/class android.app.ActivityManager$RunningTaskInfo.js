var android = {
    app: {
        ActivityManager: {
            RunningTaskInfo: class {
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                readFromParcel = function (arg0/*Parcel*/){}
                toString = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
