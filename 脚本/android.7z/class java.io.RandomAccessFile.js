var java = {
    io: {
        RandomAccessFile: class {
            length = function (){}
            write = function (arg0/*int*/){}
            write = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            write = function (arg0/*byte[]*/){}
            read = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            read = function (arg0/*byte[]*/){}
            read = function (){}
            readLine = function (){}
            close = function (){}
            writeInt = function (arg0/*int*/){}
            readInt = function (){}
            setLength = function (arg0/*long*/){}
            writeBytes = function (arg0/*String*/){}
            writeUTF = function (arg0/*String*/){}
            readUTF = function (){}
            writeFloat = function (arg0/*float*/){}
            readFloat = function (){}
            getFD = function (){}
            getChannel = function (){}
            writeChar = function (arg0/*int*/){}
            readChar = function (){}
            seek = function (arg0/*long*/){}
            readFully = function (arg0/*byte[]*/){}
            readFully = function (arg0/*byte[]*/, arg1/*int*/, arg2/*int*/){}
            skipBytes = function (arg0/*int*/){}
            getFilePointer = function (){}
            readBoolean = function (){}
            readByte = function (){}
            readUnsignedByte = function (){}
            readShort = function (){}
            readUnsignedShort = function (){}
            readLong = function (){}
            readDouble = function (){}
            writeBoolean = function (arg0/*boolean*/){}
            writeByte = function (arg0/*int*/){}
            writeShort = function (arg0/*int*/){}
            writeLong = function (arg0/*long*/){}
            writeDouble = function (arg0/*double*/){}
            writeChars = function (arg0/*String*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
