var android = {
    app: {
        PictureInPictureParams: {
            Builder: class {
                build = function (){}
                setActions = function (arg0/*List*/){}
                setAspectRatio = function (arg0/*Rational*/){}
                setSourceRectHint = function (arg0/*Rect*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
