var android = {
    app: {
        job: {
            JobParameters: class {
                getClipData = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                getExtras = function (){}
                getTransientExtras = function (){}
                getClipGrantFlags = function (){}
                getJobId = function (){}
                dequeueWork = function (){}
                getNetwork = function (){}
                completeWork = function (arg0/*JobWorkItem*/){}
                isOverrideDeadlineExpired = function (){}
                getTriggeredContentUris = function (){}
                getTriggeredContentAuthorities = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
