var android = {
    widget: {
        Filterable: class {
            getFilter = function (){}
        }
    }
}
