var java = {
    lang: {
        Cloneable: class {
        }
    }
}
