var android = {
    app: {
        KeyguardManager: {
            OnKeyguardExitResult: class {
                onKeyguardExitResult = function (arg0/*boolean*/){}
            }
        }
    }
}
