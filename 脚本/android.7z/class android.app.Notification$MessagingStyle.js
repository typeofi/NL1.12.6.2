var android = {
    app: {
        Notification: {
            MessagingStyle: class {
                getUser = function (){}
                getConversationTitle = function (){}
                setGroupConversation = function (arg0/*boolean*/){}
                isGroupConversation = function (){}
                getHistoricMessages = function (){}
                setConversationTitle = function (arg0/*CharSequence*/){}
                getMessages = function (){}
                getUserDisplayName = function (){}
                addMessage = function (arg0/*CharSequence*/, arg1/*long*/, arg2/*Person*/){}
                addMessage = function (arg0/*CharSequence*/, arg1/*long*/, arg2/*CharSequence*/){}
                addMessage = function (arg0/*Message*/){}
                addHistoricMessage = function (arg0/*Message*/){}
                build = function (){}
                setBuilder = function (arg0/*Builder*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
