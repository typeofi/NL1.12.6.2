var android = {
    widget: {
        ActionMenuView: {
            OnMenuItemClickListener: class {
                onMenuItemClick = function (arg0/*MenuItem*/){}
            }
        }
    }
}
