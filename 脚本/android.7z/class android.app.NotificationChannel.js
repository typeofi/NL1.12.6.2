var android = {
    app: {
        NotificationChannel: class {
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getName = function (){}
            setName = function (arg0/*CharSequence*/){}
            getId = function (){}
            getDescription = function (){}
            writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
            describeContents = function (){}
            getGroup = function (){}
            setDescription = function (arg0/*String*/){}
            getImportance = function (){}
            setLockscreenVisibility = function (arg0/*int*/){}
            isImportantConversation = function (){}
            setVibrationPattern = function (arg0/*long[]*/){}
            getVibrationPattern = function (){}
            getLockscreenVisibility = function (){}
            hasUserSetImportance = function (){}
            setImportance = function (arg0/*int*/){}
            getSound = function (){}
            setConversationId = function (arg0/*String*/, arg1/*String*/){}
            setShowBadge = function (arg0/*boolean*/){}
            enableVibration = function (arg0/*boolean*/){}
            enableLights = function (arg0/*boolean*/){}
            setBypassDnd = function (arg0/*boolean*/){}
            setLightColor = function (arg0/*int*/){}
            setAllowBubbles = function (arg0/*boolean*/){}
            canBypassDnd = function (){}
            setGroup = function (arg0/*String*/){}
            setSound = function (arg0/*Uri*/, arg1/*AudioAttributes*/){}
            canBubble = function (){}
            getConversationId = function (){}
            hasUserSetSound = function (){}
            getLightColor = function (){}
            shouldVibrate = function (){}
            getAudioAttributes = function (){}
            canShowBadge = function (){}
            getParentChannelId = function (){}
            shouldShowLights = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
