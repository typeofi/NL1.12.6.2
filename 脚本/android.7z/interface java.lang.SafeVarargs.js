var java = {
    lang: {
        SafeVarargs: class {
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            annotationType = function (){}
        }
    }
}
