var java = {
    io: {
        StringWriter: class {
            toString = function (){}
            append = function (arg0/*CharSequence*/, arg1/*int*/, arg2/*int*/){}
            append = function (arg0/*CharSequence*/, arg1/*int*/, arg2/*int*/){}
            append = function (arg0/*CharSequence*/, arg1/*int*/, arg2/*int*/){}
            append = function (arg0/*char*/){}
            append = function (arg0/*char*/){}
            append = function (arg0/*char*/){}
            append = function (arg0/*CharSequence*/){}
            append = function (arg0/*CharSequence*/){}
            append = function (arg0/*CharSequence*/){}
            write = function (arg0/*String*/, arg1/*int*/, arg2/*int*/){}
            write = function (arg0/*String*/){}
            write = function (arg0/*char[]*/, arg1/*int*/, arg2/*int*/){}
            write = function (arg0/*int*/){}
            flush = function (){}
            close = function (){}
            getBuffer = function (){}
            write = function (arg0/*char[]*/){}
            static nullWriter = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
