var android = {
    widget: {
        PopupMenu: class {
            inflate = function (arg0/*int*/){}
            show = function (){}
            getMenuInflater = function (){}
            getMenu = function (){}
            setGravity = function (arg0/*int*/){}
            setOnMenuItemClickListener = function (arg0/*OnMenuItemClickListener*/){}
            getGravity = function (){}
            dismiss = function (){}
            setOnDismissListener = function (arg0/*OnDismissListener*/){}
            setForceShowIcon = function (arg0/*boolean*/){}
            getDragToOpenListener = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
