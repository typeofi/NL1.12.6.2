var android = {
    widget: {
        ShareActionProvider: class {
            hasSubMenu = function (){}
            onPrepareSubMenu = function (arg0/*SubMenu*/){}
            onCreateActionView = function (){}
            setShareIntent = function (arg0/*Intent*/){}
            setOnShareTargetSelectedListener = function (arg0/*OnShareTargetSelectedListener*/){}
            setShareHistoryFileName = function (arg0/*String*/){}
            isVisible = function (){}
            refreshVisibility = function (){}
            onCreateActionView = function (arg0/*MenuItem*/){}
            overridesItemVisibility = function (){}
            setVisibilityListener = function (arg0/*VisibilityListener*/){}
            onPerformDefaultAction = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
