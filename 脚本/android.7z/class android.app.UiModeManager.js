var android = {
    app: {
        UiModeManager: class {
            setNightMode = function (arg0/*int*/){}
            getNightMode = function (){}
            disableCarMode = function (arg0/*int*/){}
            enableCarMode = function (arg0/*int*/){}
            getCurrentModeType = function (){}
            getCustomNightModeStart = function (){}
            getCustomNightModeEnd = function (){}
            setCustomNightModeEnd = function (arg0/*LocalTime*/){}
            setCustomNightModeStart = function (arg0/*LocalTime*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
