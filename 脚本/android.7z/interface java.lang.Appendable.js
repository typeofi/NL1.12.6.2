var java = {
    lang: {
        Appendable: class {
            append = function (arg0/*CharSequence*/){}
            append = function (arg0/*CharSequence*/, arg1/*int*/, arg2/*int*/){}
            append = function (arg0/*char*/){}
        }
    }
}
