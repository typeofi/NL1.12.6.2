var java = {
    lang: {
        Character: {
            Subset: class {
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
