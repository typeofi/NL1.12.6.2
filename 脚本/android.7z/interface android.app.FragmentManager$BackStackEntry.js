var android = {
    app: {
        FragmentManager: {
            BackStackEntry: class {
                getName = function (){}
                getId = function (){}
                getBreadCrumbShortTitleRes = function (){}
                getBreadCrumbTitleRes = function (){}
                getBreadCrumbShortTitle = function (){}
                getBreadCrumbTitle = function (){}
            }
        }
    }
}
