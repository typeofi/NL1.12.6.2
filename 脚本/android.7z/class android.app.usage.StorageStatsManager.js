var android = {
    app: {
        usage: {
            StorageStatsManager: class {
                getTotalBytes = function (arg0/*UUID*/){}
                queryStatsForUid = function (arg0/*UUID*/, arg1/*int*/){}
                queryStatsForUser = function (arg0/*UUID*/, arg1/*UserHandle*/){}
                getFreeBytes = function (arg0/*UUID*/){}
                queryStatsForPackage = function (arg0/*UUID*/, arg1/*String*/, arg2/*UserHandle*/){}
                queryExternalStatsForUser = function (arg0/*UUID*/, arg1/*UserHandle*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
