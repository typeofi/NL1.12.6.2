var android = {
    app: {
        job: {
            JobServiceEngine: class {
                getBinder = function (){}
                onStopJob = function (arg0/*JobParameters*/){}
                jobFinished = function (arg0/*JobParameters*/, arg1/*boolean*/){}
                onStartJob = function (arg0/*JobParameters*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
