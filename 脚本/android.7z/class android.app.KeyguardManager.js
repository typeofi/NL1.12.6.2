var android = {
    app: {
        KeyguardManager: class {
            createConfirmDeviceCredentialIntent = function (arg0/*CharSequence*/, arg1/*CharSequence*/){}
            isDeviceSecure = function (){}
            isKeyguardSecure = function (){}
            newKeyguardLock = function (arg0/*String*/){}
            isKeyguardLocked = function (){}
            isDeviceLocked = function (){}
            inKeyguardRestrictedInputMode = function (){}
            requestDismissKeyguard = function (arg0/*Activity*/, arg1/*KeyguardDismissCallback*/){}
            exitKeyguardSecurely = function (arg0/*OnKeyguardExitResult*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
