var android = {
    app: {
        Notification: {
            Action: class {
                clone = function (){}
                clone = function (){}
                getIcon = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                getExtras = function (){}
                getAllowGeneratedReplies = function (){}
                getDataOnlyRemoteInputs = function (){}
                getRemoteInputs = function (){}
                isContextual = function (){}
                getSemanticAction = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
