var java = {
    io: {
        Flushable: class {
            flush = function (){}
        }
    }
}
