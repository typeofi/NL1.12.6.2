var android = {
    widget: {
        Magnifier: class {
            update = function (){}
            getPosition = function (){}
            getWidth = function (){}
            getHeight = function (){}
            getElevation = function (){}
            getOverlay = function (){}
            show = function (arg0/*float*/, arg1/*float*/){}
            show = function (arg0/*float*/, arg1/*float*/, arg2/*float*/, arg3/*float*/){}
            dismiss = function (){}
            getDefaultHorizontalSourceToMagnifierOffset = function (){}
            getDefaultVerticalSourceToMagnifierOffset = function (){}
            isClippingEnabled = function (){}
            getZoom = function (){}
            getSourcePosition = function (){}
            getCornerRadius = function (){}
            setZoom = function (arg0/*float*/){}
            getSourceWidth = function (){}
            getSourceHeight = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
