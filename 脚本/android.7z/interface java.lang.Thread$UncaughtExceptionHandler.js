var java = {
    lang: {
        Thread: {
            UncaughtExceptionHandler: class {
                uncaughtException = function (arg0/*Thread*/, arg1/*Throwable*/){}
            }
        }
    }
}
