var java = {
    lang: {
        reflect: {
            Type: class {
                getTypeName = function (){}
            }
        }
    }
}
