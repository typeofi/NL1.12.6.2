var android = {
    app: {
        slice: {
            SliceItem: class {
                getInt = function (){}
                getLong = function (){}
                getFormat = function (){}
                getBundle = function (){}
                getText = function (){}
                getIcon = function (){}
                getAction = function (){}
                writeToParcel = function (arg0/*Parcel*/, arg1/*int*/){}
                describeContents = function (){}
                getSlice = function (){}
                hasHint = function (arg0/*String*/){}
                getSubType = function (){}
                getRemoteInput = function (){}
                getHints = function (){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
