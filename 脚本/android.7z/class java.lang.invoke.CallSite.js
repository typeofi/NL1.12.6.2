var java = {
    lang: {
        invoke: {
            CallSite: class {
                type = function (){}
                dynamicInvoker = function (){}
                getTarget = function (){}
                setTarget = function (arg0/*MethodHandle*/){}
                wait = function (arg0/*long*/){}
                wait = function (arg0/*long*/, arg1/*int*/){}
                wait = function (){}
                equals = function (arg0/*Object*/){}
                toString = function (){}
                hashCode = function (){}
                getClass = function (){}
                notify = function (){}
                notifyAll = function (){}
            }
        }
    }
}
