var android = {
    os: {
        Process: class {
            static getStartUptimeMillis = function (){}
            static getStartElapsedRealtime = function (){}
            static isIsolated = function (){}
            static getGidForName = function (arg0/*String*/){}
            static setThreadPriority = function (arg0/*int*/){}
            static setThreadPriority = function (arg0/*int*/, arg1/*int*/){}
            static getUidForName = function (arg0/*String*/){}
            static getExclusiveCores = function (){}
            static getThreadPriority = function (arg0/*int*/){}
            static supportsProcesses = function (){}
            static myUid = function (){}
            static myUserHandle = function (){}
            static is64Bit = function (){}
            static myPid = function (){}
            static myTid = function (){}
            static getElapsedCpuTime = function (){}
            static isApplicationUid = function (arg0/*int*/){}
            static killProcess = function (arg0/*int*/){}
            static sendSignal = function (arg0/*int*/, arg1/*int*/){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
