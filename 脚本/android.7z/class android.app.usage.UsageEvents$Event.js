var android = {
    app: {
        usage: {
            UsageEvents: {
                Event: class {
                    getPackageName = function (){}
                    getClassName = function (){}
                    getTimeStamp = function (){}
                    getEventType = function (){}
                    getConfiguration = function (){}
                    getShortcutId = function (){}
                    getAppStandbyBucket = function (){}
                    wait = function (arg0/*long*/){}
                    wait = function (arg0/*long*/, arg1/*int*/){}
                    wait = function (){}
                    equals = function (arg0/*Object*/){}
                    toString = function (){}
                    hashCode = function (){}
                    getClass = function (){}
                    notify = function (){}
                    notifyAll = function (){}
                }
            }
        }
    }
}
