var java = {
    io: {
        FilterReader: class {
            read = function (arg0/*char[]*/, arg1/*int*/, arg2/*int*/){}
            read = function (){}
            close = function (){}
            mark = function (arg0/*int*/){}
            skip = function (arg0/*long*/){}
            markSupported = function (){}
            reset = function (){}
            ready = function (){}
            read = function (arg0/*char[]*/){}
            read = function (arg0/*CharBuffer*/){}
            transferTo = function (arg0/*Writer*/){}
            static nullReader = function (){}
            wait = function (arg0/*long*/){}
            wait = function (arg0/*long*/, arg1/*int*/){}
            wait = function (){}
            equals = function (arg0/*Object*/){}
            toString = function (){}
            hashCode = function (){}
            getClass = function (){}
            notify = function (){}
            notifyAll = function (){}
        }
    }
}
