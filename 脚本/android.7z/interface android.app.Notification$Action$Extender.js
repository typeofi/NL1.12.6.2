var android = {
    app: {
        Notification: {
            Action: {
                Extender: class {
                    extend = function (arg0/*Builder*/){}
                }
            }
        }
    }
}
